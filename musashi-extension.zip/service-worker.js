/******/ (() => { // webpackBootstrap
/******/ 	"use strict";

;// ./src/data/mock-markets.ts
// Mock Kalshi market data for MVP testing
const mockMarkets = [
    // ── US Politics ───────────────────────────────────────────────────────────
    {
        id: 'kalshi-trump-2024',
        platform: 'kalshi',
        title: 'Will Donald Trump win the 2024 presidential election?',
        description: 'This market resolves to Yes if Donald Trump wins the 2024 U.S. presidential election.',
        keywords: ['trump', 'donald trump', 'republican', 'gop', 'white house', 'maga', 'presidential race'],
        yesPrice: 0.48,
        noPrice: 0.52,
        volume24h: 487000,
        url: 'https://kalshi.com/markets',
        category: 'us_politics',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-biden-reelection',
        platform: 'kalshi',
        title: 'Will Joe Biden be the Democratic nominee in 2024?',
        description: 'Resolves Yes if Joe Biden is officially nominated as the Democratic candidate.',
        keywords: ['biden', 'joe biden', 'democrat', 'democratic', 'nominee', 'nomination', 'democratic party'],
        yesPrice: 0.23,
        noPrice: 0.77,
        volume24h: 245000,
        url: 'https://kalshi.com/markets',
        category: 'us_politics',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-congress-control',
        platform: 'kalshi',
        title: 'Will Republicans control the House in 2025?',
        description: 'This market resolves to Yes if Republicans hold a majority in the House of Representatives in 2025.',
        keywords: ['congress', 'house of representatives', 'republican', 'gop', 'majority', 'speaker', 'midterm'],
        yesPrice: 0.61,
        noPrice: 0.39,
        volume24h: 156000,
        url: 'https://kalshi.com/markets',
        category: 'us_politics',
        lastUpdated: new Date().toISOString(),
    },
    // ── Economics & Fed Policy ─────────────────────────────────────────────────
    {
        id: 'kalshi-fed-rate-cut',
        platform: 'kalshi',
        title: 'Will the Fed cut interest rates in March 2026?',
        description: 'Resolves Yes if the Federal Reserve cuts the federal funds rate at their March 2026 meeting.',
        keywords: ['fed', 'federal reserve', 'interest rate', 'rate cut', 'fomc', 'jerome powell', 'powell', 'monetary policy'],
        yesPrice: 0.72,
        noPrice: 0.28,
        volume24h: 389000,
        url: 'https://kalshi.com/markets',
        category: 'monetary_policy',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-inflation-cpi',
        platform: 'kalshi',
        title: 'Will CPI inflation be above 3% in February?',
        description: 'Resolves Yes if the Consumer Price Index year-over-year change is above 3.0% for February 2026.',
        keywords: ['inflation', 'cpi', 'consumer price index', 'cost of living', 'pce', 'core inflation'],
        yesPrice: 0.58,
        noPrice: 0.42,
        volume24h: 203000,
        url: 'https://kalshi.com/markets',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-recession-2026',
        platform: 'kalshi',
        title: 'Will the US enter a recession in 2026?',
        description: 'Resolves Yes if the NBER declares a recession beginning in 2026.',
        keywords: ['recession', 'economic downturn', 'gdp', 'contraction', 'nber', 'negative growth'],
        yesPrice: 0.34,
        noPrice: 0.66,
        volume24h: 412000,
        url: 'https://kalshi.com/markets',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-unemployment',
        platform: 'kalshi',
        title: 'Will unemployment rate exceed 4.5% in March?',
        description: 'Resolves Yes if the US unemployment rate is above 4.5% in the March 2026 jobs report.',
        keywords: ['unemployment', 'jobs', 'jobless', 'labor market', 'layoffs', 'nonfarm payrolls', 'nfp'],
        yesPrice: 0.29,
        noPrice: 0.71,
        volume24h: 167000,
        url: 'https://kalshi.com/markets',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
    },
    // ── Technology ─────────────────────────────────────────────────────────────
    {
        id: 'kalshi-apple-earnings',
        platform: 'kalshi',
        title: 'Will Apple beat earnings expectations in Q1 2026?',
        description: 'Resolves Yes if Apple reports Q1 2026 earnings above analyst consensus.',
        keywords: ['apple', 'aapl', 'iphone', 'tim cook', 'earnings per share', 'eps', 'cupertino'],
        yesPrice: 0.55,
        noPrice: 0.45,
        volume24h: 298000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-ai-regulation',
        platform: 'kalshi',
        title: 'Will the US pass major AI regulation in 2026?',
        description: 'Resolves Yes if Congress passes and the President signs significant AI regulation legislation in 2026.',
        keywords: ['ai regulation', 'ai safety', 'openai', 'anthropic', 'llm', 'agi', 'chatgpt', 'eu ai act', 'ai bill'],
        yesPrice: 0.41,
        noPrice: 0.59,
        volume24h: 275000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-nvidia-market-cap',
        platform: 'kalshi',
        title: 'Will NVIDIA reach $5 trillion market cap in 2026?',
        description: 'Resolves Yes if NVIDIA market capitalization reaches or exceeds $5 trillion at any point in 2026.',
        keywords: ['nvidia', 'nvda', 'gpu', 'ai chips', 'jensen huang', 'semiconductors', 'data center'],
        yesPrice: 0.38,
        noPrice: 0.62,
        volume24h: 445000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    // ── Crypto ─────────────────────────────────────────────────────────────────
    {
        id: 'kalshi-bitcoin-100k',
        platform: 'kalshi',
        title: 'Will Bitcoin reach $100,000 in 2026?',
        description: 'Resolves Yes if Bitcoin (BTC) trades at or above $100,000 at any point in 2026.',
        keywords: ['bitcoin', 'btc', '100k', 'satoshi', 'halving', 'coinbase', 'spot etf'],
        yesPrice: 0.67,
        noPrice: 0.33,
        volume24h: 623000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-ethereum-5k',
        platform: 'kalshi',
        title: 'Will Ethereum reach $5,000 in 2026?',
        description: 'Resolves Yes if Ethereum (ETH) trades at or above $5,000 at any point in 2026.',
        keywords: ['ethereum', 'eth', 'defi', 'vitalik', 'buterin', 'staking', 'layer 2'],
        yesPrice: 0.52,
        noPrice: 0.48,
        volume24h: 387000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-crypto-etf',
        platform: 'kalshi',
        title: 'Will SEC approve Ethereum spot ETF in 2026?',
        description: 'Resolves Yes if the SEC approves a spot Ethereum ETF for trading in 2026.',
        keywords: ['etf', 'sec', 'ethereum', 'eth', 'spot etf', 'securities', 'bitcoin etf', 'gensler'],
        yesPrice: 0.73,
        noPrice: 0.27,
        volume24h: 291000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    // ── Sports ─────────────────────────────────────────────────────────────────
    {
        id: 'kalshi-super-bowl',
        platform: 'kalshi',
        title: 'Will the Kansas City Chiefs win Super Bowl 2026?',
        description: 'Resolves Yes if the Kansas City Chiefs win Super Bowl LX.',
        keywords: ['super bowl', 'nfl', 'football', 'chiefs', 'kansas city', 'patrick mahomes', 'mahomes'],
        yesPrice: 0.31,
        noPrice: 0.69,
        volume24h: 512000,
        url: 'https://kalshi.com/markets',
        category: 'sports',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-nba-champions',
        platform: 'kalshi',
        title: 'Will the Boston Celtics win the 2026 NBA Championship?',
        description: 'Resolves Yes if the Boston Celtics win the 2026 NBA Finals.',
        keywords: ['nba', 'basketball', 'celtics', 'boston', 'nba finals', 'jayson tatum', 'playoffs'],
        yesPrice: 0.28,
        noPrice: 0.72,
        volume24h: 234000,
        url: 'https://kalshi.com/markets',
        category: 'sports',
        lastUpdated: new Date().toISOString(),
    },
    // ── Climate & Weather ──────────────────────────────────────────────────────
    {
        id: 'kalshi-temperature-record',
        platform: 'kalshi',
        title: 'Will 2026 be the hottest year on record?',
        description: 'Resolves Yes if 2026 is declared the hottest year globally on record by major climate organizations.',
        keywords: ['climate', 'global warming', 'climate change', 'carbon emissions', 'noaa', 'nasa temperature'],
        yesPrice: 0.44,
        noPrice: 0.56,
        volume24h: 178000,
        url: 'https://kalshi.com/markets',
        category: 'climate',
        lastUpdated: new Date().toISOString(),
    },
    // ── Geopolitics ────────────────────────────────────────────────────────────
    {
        id: 'kalshi-china-taiwan',
        platform: 'kalshi',
        title: 'Will there be a military conflict over Taiwan in 2026?',
        description: 'Resolves Yes if there is military action between China and Taiwan in 2026.',
        keywords: ['china', 'taiwan', 'xi jinping', 'pla', 'strait', 'tsmc', 'beijing', 'prc'],
        yesPrice: 0.12,
        noPrice: 0.88,
        volume24h: 334000,
        url: 'https://kalshi.com/markets',
        category: 'geopolitics',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-ukraine-peace',
        platform: 'kalshi',
        title: 'Will Ukraine and Russia reach a peace agreement in 2026?',
        description: 'Resolves Yes if a formal peace agreement is signed between Ukraine and Russia in 2026.',
        keywords: ['ukraine', 'russia', 'putin', 'zelensky', 'peace deal', 'ceasefire', 'nato', 'donbas'],
        yesPrice: 0.36,
        noPrice: 0.64,
        volume24h: 412000,
        url: 'https://kalshi.com/markets',
        category: 'geopolitics',
        lastUpdated: new Date().toISOString(),
    },
    // ── Entertainment ──────────────────────────────────────────────────────────
    {
        id: 'kalshi-oscars-best-picture',
        platform: 'kalshi',
        title: 'Will Oppenheimer win Best Picture at the 2026 Oscars?',
        description: 'Resolves Yes if Oppenheimer wins the Academy Award for Best Picture.',
        keywords: ['oscars', 'academy awards', 'best picture', 'oppenheimer', 'nolan', 'film', 'hollywood'],
        yesPrice: 0.68,
        noPrice: 0.32,
        volume24h: 145000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    // ── Crypto (expanded) ──────────────────────────────────────────────────────
    {
        id: 'kalshi-solana-price',
        platform: 'kalshi',
        title: 'Will Solana reach $400 in 2026?',
        description: 'Resolves Yes if Solana (SOL) trades at or above $400 at any point in 2026.',
        keywords: ['solana', 'sol', 'phantom', 'solana ecosystem', 'pump fun', 'memecoin'],
        yesPrice: 0.44,
        noPrice: 0.56,
        volume24h: 298000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-xrp-price',
        platform: 'kalshi',
        title: 'Will XRP reach $5 in 2026?',
        description: 'Resolves Yes if XRP (Ripple) trades at or above $5 at any point in 2026.',
        keywords: ['xrp', 'ripple', 'sec', 'crypto regulation', 'brad garlinghouse'],
        yesPrice: 0.39,
        noPrice: 0.61,
        volume24h: 187000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-ethereum-l2',
        platform: 'kalshi',
        title: 'Will Ethereum Layer 2 TVL exceed $100B in 2026?',
        description: 'Resolves Yes if total value locked across Ethereum L2 networks exceeds $100 billion.',
        keywords: ['ethereum', 'eth', 'layer 2', 'l2', 'arbitrum', 'optimism', 'polygon', 'base', 'defi', 'web3', 'staking'],
        yesPrice: 0.51,
        noPrice: 0.49,
        volume24h: 142000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-crypto-market-cap',
        platform: 'kalshi',
        title: 'Will total crypto market cap exceed $5 trillion in 2026?',
        description: 'Resolves Yes if the total cryptocurrency market capitalization exceeds $5 trillion.',
        keywords: ['crypto', 'cryptocurrency', 'bitcoin', 'ethereum', 'bull run', 'altcoin', 'blockchain'],
        yesPrice: 0.58,
        noPrice: 0.42,
        volume24h: 412000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-defi-tvl',
        platform: 'kalshi',
        title: 'Will DeFi total value locked exceed $200B in 2026?',
        description: 'Resolves Yes if total DeFi TVL across all chains exceeds $200 billion.',
        keywords: ['defi', 'decentralized finance', 'tvl', 'ethereum', 'eth', 'dapp', 'web3', 'yield', 'liquidity'],
        yesPrice: 0.46,
        noPrice: 0.54,
        volume24h: 98000,
        url: 'https://kalshi.com/markets',
        category: 'crypto',
        lastUpdated: new Date().toISOString(),
    },
    // ── Technology (expanded) ──────────────────────────────────────────────────
    {
        id: 'kalshi-openai-valuation',
        platform: 'kalshi',
        title: 'Will OpenAI reach $300B valuation in 2026?',
        description: 'Resolves Yes if OpenAI raises funding or is valued at $300B or more in 2026.',
        keywords: ['openai', 'sam altman', 'chatgpt', 'gpt', 'llm', 'agi', 'altman', 'artificial intelligence'],
        yesPrice: 0.62,
        noPrice: 0.38,
        volume24h: 334000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-tesla-stock',
        platform: 'kalshi',
        title: 'Will Tesla stock exceed $500 in 2026?',
        description: 'Resolves Yes if Tesla (TSLA) share price exceeds $500 at any point in 2026.',
        keywords: ['tesla', 'tsla', 'elon musk', 'musk', 'ev', 'electric vehicle', 'cybertruck', 'autopilot'],
        yesPrice: 0.41,
        noPrice: 0.59,
        volume24h: 389000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-microsoft-ai',
        platform: 'kalshi',
        title: 'Will Microsoft Copilot reach 100M users in 2026?',
        description: 'Resolves Yes if Microsoft reports 100M+ active Copilot users in 2026.',
        keywords: ['microsoft', 'msft', 'copilot', 'openai', 'llm', 'ai', 'satya nadella', 'azure'],
        yesPrice: 0.55,
        noPrice: 0.45,
        volume24h: 167000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-google-ai',
        platform: 'kalshi',
        title: 'Will Google Gemini surpass ChatGPT in users by end of 2026?',
        description: 'Resolves Yes if Google Gemini reports more monthly active users than ChatGPT.',
        keywords: ['google', 'gemini', 'chatgpt', 'openai', 'llm', 'alphabet', 'googl', 'ai', 'sundar pichai'],
        yesPrice: 0.33,
        noPrice: 0.67,
        volume24h: 221000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    // ── Economics (expanded) ───────────────────────────────────────────────────
    {
        id: 'kalshi-sp500-level',
        platform: 'kalshi',
        title: 'Will the S&P 500 reach 7,000 in 2026?',
        description: 'Resolves Yes if the S&P 500 index closes at or above 7,000 at any point in 2026.',
        keywords: ['s&p 500', 'sp500', 'stocks', 'equities', 'nasdaq', 'dow jones', 'bull market'],
        yesPrice: 0.63,
        noPrice: 0.37,
        volume24h: 534000,
        url: 'https://kalshi.com/markets',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-oil-price',
        platform: 'kalshi',
        title: 'Will crude oil exceed $100 per barrel in 2026?',
        description: 'Resolves Yes if WTI crude oil trades above $100/barrel at any point in 2026.',
        keywords: ['oil', 'crude', 'wti', 'brent', 'opec', 'energy', 'barrel', 'gasoline'],
        yesPrice: 0.28,
        noPrice: 0.72,
        volume24h: 276000,
        url: 'https://kalshi.com/markets',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
    },
    // ── Politics (expanded) ────────────────────────────────────────────────────
    {
        id: 'kalshi-trump-impeachment',
        platform: 'kalshi',
        title: 'Will Trump face impeachment proceedings in 2026?',
        description: 'Resolves Yes if the House votes to begin impeachment proceedings against Trump in 2026.',
        keywords: ['trump', 'impeachment', 'congress', 'house', 'republicans', 'democrats', 'white house'],
        yesPrice: 0.18,
        noPrice: 0.82,
        volume24h: 312000,
        url: 'https://kalshi.com/markets',
        category: 'us_politics',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-doge-cuts',
        platform: 'kalshi',
        title: 'Will DOGE cut $1 trillion in federal spending?',
        description: 'Resolves Yes if the Department of Government Efficiency achieves $1T in identified spending cuts.',
        keywords: ['doge', 'elon musk', 'musk', 'spending cuts', 'federal budget', 'government efficiency', 'vivek'],
        yesPrice: 0.22,
        noPrice: 0.78,
        volume24h: 445000,
        url: 'https://kalshi.com/markets',
        category: 'us_politics',
        lastUpdated: new Date().toISOString(),
    },
    // ── Sports (expanded) ──────────────────────────────────────────────────────
    {
        id: 'kalshi-messi-retirement',
        platform: 'kalshi',
        title: 'Will Messi retire from professional soccer in 2026?',
        description: 'Resolves Yes if Lionel Messi announces retirement from professional soccer in 2026.',
        keywords: ['messi', 'lionel messi', 'inter miami', 'soccer', 'football', 'mls', 'world cup'],
        yesPrice: 0.24,
        noPrice: 0.76,
        volume24h: 189000,
        url: 'https://kalshi.com/markets',
        category: 'sports',
        lastUpdated: new Date().toISOString(),
    },
    // ── Anime & Entertainment (expanded) ───────────────────────────────────────
    {
        id: 'kalshi-attack-on-titan-final',
        platform: 'kalshi',
        title: 'Will Attack on Titan finale be most-watched anime episode of 2026?',
        description: 'Resolves Yes if Attack on Titan final episode has the highest viewership of any anime episode in 2026.',
        keywords: ['anime', 'attack on titan', 'aot', 'shingeki no kyojin', 'mappa', 'crunchyroll', 'funimation'],
        yesPrice: 0.45,
        noPrice: 0.55,
        volume24h: 98000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-chainsaw-man-season2',
        platform: 'kalshi',
        title: 'Will Chainsaw Man Season 2 release in 2026?',
        description: 'Resolves Yes if Chainsaw Man Season 2 officially releases in 2026.',
        keywords: ['anime', 'chainsaw man', 'csm', 'mappa', 'manga', 'crunchyroll', 'shonen jump'],
        yesPrice: 0.68,
        noPrice: 0.32,
        volume24h: 145000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-studio-ghibli',
        platform: 'kalshi',
        title: 'Will new Studio Ghibli film release in 2026?',
        description: 'Resolves Yes if Studio Ghibli releases a new theatrical film in 2026.',
        keywords: ['anime', 'studio ghibli', 'ghibli', 'miyazaki', 'hayao miyazaki', 'spirited away', 'totoro'],
        yesPrice: 0.52,
        noPrice: 0.48,
        volume24h: 87000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-my-hero-academia',
        platform: 'kalshi',
        title: 'Will My Hero Academia manga end in 2026?',
        description: 'Resolves Yes if My Hero Academia manga officially concludes in 2026.',
        keywords: ['anime', 'my hero academia', 'mha', 'boku no hero', 'manga', 'shonen jump', 'horikoshi'],
        yesPrice: 0.71,
        noPrice: 0.29,
        volume24h: 112000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-demon-slayer-movie',
        platform: 'kalshi',
        title: 'Will new Demon Slayer movie gross over $500M worldwide?',
        description: 'Resolves Yes if the next Demon Slayer theatrical film grosses over $500M globally.',
        keywords: ['anime', 'demon slayer', 'kimetsu no yaiba', 'ufotable', 'movie', 'box office', 'crunchyroll'],
        yesPrice: 0.39,
        noPrice: 0.61,
        volume24h: 156000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-one-piece-1200',
        platform: 'kalshi',
        title: 'Will One Piece reach Chapter 1200 in 2026?',
        description: 'Resolves Yes if One Piece manga publishes Chapter 1200 in 2026.',
        keywords: ['anime', 'one piece', 'manga', 'eiichiro oda', 'luffy', 'shonen jump', 'toei'],
        yesPrice: 0.82,
        noPrice: 0.18,
        volume24h: 203000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-crunchyroll-subscribers',
        platform: 'kalshi',
        title: 'Will Crunchyroll reach 20M subscribers in 2026?',
        description: 'Resolves Yes if Crunchyroll reports 20M+ paid subscribers in 2026.',
        keywords: ['anime', 'crunchyroll', 'streaming', 'subscribers', 'sony', 'funimation'],
        yesPrice: 0.63,
        noPrice: 0.37,
        volume24h: 134000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    // ── Creator Economy & Content ──────────────────────────────────────────────
    {
        id: 'kalshi-tiktok-creators',
        platform: 'kalshi',
        title: 'Will TikTok creator fund pay out over $2B in 2026?',
        description: 'Resolves Yes if TikTok creator fund total payouts exceed $2 billion in 2026.',
        keywords: ['tiktok', 'creator', 'content creator', 'influencer', 'social media', 'short form', 'creator economy'],
        yesPrice: 0.55,
        noPrice: 0.45,
        volume24h: 198000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-youtube-shorts',
        platform: 'kalshi',
        title: 'Will YouTube Shorts exceed 100B daily views in 2026?',
        description: 'Resolves Yes if YouTube reports 100B+ daily Shorts views in 2026.',
        keywords: ['youtube', 'youtube shorts', 'shorts', 'google', 'creator', 'content creator', 'video'],
        yesPrice: 0.61,
        noPrice: 0.39,
        volume24h: 223000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-instagram-reels',
        platform: 'kalshi',
        title: 'Will Instagram Reels surpass TikTok in daily users?',
        description: 'Resolves Yes if Instagram Reels reports more daily active users than TikTok in 2026.',
        keywords: ['instagram', 'reels', 'meta', 'tiktok', 'short form', 'social media', 'content creator'],
        yesPrice: 0.42,
        noPrice: 0.58,
        volume24h: 287000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-ai-content-tools',
        platform: 'kalshi',
        title: 'Will AI video generation tools reach 50M users in 2026?',
        description: 'Resolves Yes if AI video tools (like Sora, Runway, Pika) collectively reach 50M+ users.',
        keywords: ['ai', 'ai video', 'video generation', 'sora', 'runway', 'pika', 'generative ai', 'content creation'],
        yesPrice: 0.58,
        noPrice: 0.42,
        volume24h: 312000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-twitch-revenue',
        platform: 'kalshi',
        title: 'Will Twitch annual revenue exceed $5B in 2026?',
        description: 'Resolves Yes if Twitch reports over $5 billion in annual revenue for 2026.',
        keywords: ['twitch', 'streaming', 'amazon', 'content creator', 'streamer', 'gaming', 'live stream'],
        yesPrice: 0.47,
        noPrice: 0.53,
        volume24h: 176000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-ai-anime-generation',
        platform: 'kalshi',
        title: 'Will AI-generated anime reach mainstream adoption in 2026?',
        description: 'Resolves Yes if a major streaming platform releases an AI-generated anime series in 2026.',
        keywords: ['ai', 'anime', 'generative ai', 'ai animation', 'ai video', 'machine learning', 'content creation'],
        yesPrice: 0.33,
        noPrice: 0.67,
        volume24h: 245000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-mrbeast-subscribers',
        platform: 'kalshi',
        title: 'Will MrBeast reach 500M YouTube subscribers in 2026?',
        description: 'Resolves Yes if MrBeast main channel reaches 500M subscribers in 2026.',
        keywords: ['mrbeast', 'youtube', 'content creator', 'influencer', 'subscribers', 'jimmy donaldson'],
        yesPrice: 0.28,
        noPrice: 0.72,
        volume24h: 198000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    // ── Film & Streaming ───────────────────────────────────────────────────────
    {
        id: 'kalshi-netflix-anime',
        platform: 'kalshi',
        title: 'Will Netflix produce 50+ original anime titles in 2026?',
        description: 'Resolves Yes if Netflix releases 50 or more original anime titles in 2026.',
        keywords: ['netflix', 'anime', 'streaming', 'original content', 'japanese animation'],
        yesPrice: 0.56,
        noPrice: 0.44,
        volume24h: 167000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-disney-plus-anime',
        platform: 'kalshi',
        title: 'Will Disney+ launch dedicated anime hub in 2026?',
        description: 'Resolves Yes if Disney+ creates a dedicated anime content section in 2026.',
        keywords: ['disney', 'disney plus', 'anime', 'streaming', 'japanese animation'],
        yesPrice: 0.41,
        noPrice: 0.59,
        volume24h: 134000,
        url: 'https://kalshi.com/markets',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
    },
    {
        id: 'kalshi-cartoon-edits',
        platform: 'kalshi',
        title: 'Will AI cartoon editing tools reach 10M users in 2026?',
        description: 'Resolves Yes if AI-powered cartoon/animation editing tools collectively reach 10M+ users.',
        keywords: ['cartoon', 'animation', 'ai editing', 'video editing', 'ai tools', 'content creation', 'editing software'],
        yesPrice: 0.64,
        noPrice: 0.36,
        volume24h: 189000,
        url: 'https://kalshi.com/markets',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
    },
    // Additional Polymarket markets to add to mock-markets.ts
    // These cover diverse interests: gaming, music, social media, science, lifestyle, fashion, finance
    // ── Gaming & Esports ───────────────────────────────────────────────────────
    {
        id: 'poly-gta-6-price',
        platform: 'polymarket',
        title: 'Will GTA 6 cost $100+ at launch?',
        description: 'Resolves Yes if Grand Theft Auto 6 standard edition price is $100 or more at launch.',
        keywords: ['gta', 'gta 6', 'grand theft auto', 'rockstar', 'video game', 'gaming', 'game price', 'take two'],
        yesPrice: 0.34,
        noPrice: 0.66,
        volume24h: 567000,
        url: 'https://polymarket.com/event/gta-6-price',
        category: 'gaming',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.03,
    },
    {
        id: 'poly-elden-ring-dlc',
        platform: 'polymarket',
        title: 'Will Elden Ring get another DLC in 2026?',
        description: 'Resolves Yes if FromSoftware announces or releases additional Elden Ring DLC in 2026.',
        keywords: ['elden ring', 'fromsoftware', 'dlc', 'souls', 'gaming', 'video game', 'rpg', 'george rr martin'],
        yesPrice: 0.41,
        noPrice: 0.59,
        volume24h: 289000,
        url: 'https://polymarket.com/event/elden-ring-dlc',
        category: 'gaming',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: -0.02,
    },
    {
        id: 'poly-league-worlds',
        platform: 'polymarket',
        title: 'Will a Western team win LoL Worlds 2026?',
        description: 'Resolves Yes if a North American or European team wins League of Legends World Championship 2026.',
        keywords: ['league of legends', 'lol', 'esports', 'worlds', 't1', 'faker', 'gaming', 'riot games', 'competitive gaming'],
        yesPrice: 0.18,
        noPrice: 0.82,
        volume24h: 412000,
        url: 'https://polymarket.com/event/lol-worlds',
        category: 'gaming',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-11-15',
        oneDayPriceChange: 0.01,
    },
    {
        id: 'poly-nintendo-switch-2',
        platform: 'polymarket',
        title: 'Will Nintendo Switch 2 launch in 2026?',
        description: 'Resolves Yes if Nintendo officially releases the Switch successor console in 2026.',
        keywords: ['nintendo', 'switch', 'switch 2', 'gaming', 'console', 'zelda', 'mario', 'pokemon'],
        yesPrice: 0.87,
        noPrice: 0.13,
        volume24h: 723000,
        url: 'https://polymarket.com/event/switch-2',
        category: 'gaming',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.05,
    },
    {
        id: 'poly-valorant-champions',
        platform: 'polymarket',
        title: 'Will Sentinels win Valorant Champions 2026?',
        description: 'Resolves Yes if Sentinels wins the Valorant Champions Tour 2026 championship.',
        keywords: ['valorant', 'sentinels', 'tenz', 'esports', 'fps', 'riot games', 'gaming', 'competitive'],
        yesPrice: 0.26,
        noPrice: 0.74,
        volume24h: 298000,
        url: 'https://polymarket.com/event/val-champions',
        category: 'gaming',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-08-31',
    },
    {
        id: 'poly-minecraft-2',
        platform: 'polymarket',
        title: 'Will Minecraft 2 be announced in 2026?',
        description: 'Resolves Yes if Mojang/Microsoft officially announces a Minecraft sequel in 2026.',
        keywords: ['minecraft', 'mojang', 'microsoft', 'gaming', 'sandbox', 'video game'],
        yesPrice: 0.15,
        noPrice: 0.85,
        volume24h: 187000,
        url: 'https://polymarket.com/event/minecraft-2',
        category: 'gaming',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    {
        id: 'poly-silksong-release',
        platform: 'polymarket',
        title: 'Will Hollow Knight: Silksong release in 2026?',
        description: 'Resolves Yes if Hollow Knight: Silksong officially launches in 2026.',
        keywords: ['hollow knight', 'silksong', 'indie game', 'metroidvania', 'gaming', 'team cherry'],
        yesPrice: 0.62,
        noPrice: 0.38,
        volume24h: 345000,
        url: 'https://polymarket.com/event/silksong',
        category: 'gaming',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.04,
    },
    // ── Music & Entertainment ──────────────────────────────────────────────────
    {
        id: 'poly-taylor-swift-album',
        platform: 'polymarket',
        title: 'Will Taylor Swift release a new album in 2026?',
        description: 'Resolves Yes if Taylor Swift releases a new studio album (not re-recording) in 2026.',
        keywords: ['taylor swift', 'music', 'album', 'pop music', 'swifties', 'concert', 'eras tour'],
        yesPrice: 0.71,
        noPrice: 0.29,
        volume24h: 456000,
        url: 'https://polymarket.com/event/taylor-swift-album',
        category: 'music',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.02,
    },
    {
        id: 'poly-kendrick-drake',
        platform: 'polymarket',
        title: 'Will Kendrick and Drake collaborate in 2026?',
        description: 'Resolves Yes if Kendrick Lamar and Drake release a song together in 2026.',
        keywords: ['kendrick lamar', 'drake', 'rap', 'hip hop', 'music', 'collaboration', 'beef'],
        yesPrice: 0.08,
        noPrice: 0.92,
        volume24h: 234000,
        url: 'https://polymarket.com/event/kendrick-drake',
        category: 'music',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    {
        id: 'poly-beyonce-tour',
        platform: 'polymarket',
        title: 'Will Beyoncé announce a world tour in 2026?',
        description: 'Resolves Yes if Beyoncé officially announces a multi-city world tour in 2026.',
        keywords: ['beyonce', 'music', 'tour', 'concert', 'renaissance', 'pop'],
        yesPrice: 0.64,
        noPrice: 0.36,
        volume24h: 378000,
        url: 'https://polymarket.com/event/beyonce-tour',
        category: 'music',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.06,
    },
    {
        id: 'poly-coachella-headliner',
        platform: 'polymarket',
        title: 'Will The Weeknd headline Coachella 2026?',
        description: 'Resolves Yes if The Weeknd is announced as a Coachella 2026 headliner.',
        keywords: ['coachella', 'the weeknd', 'music festival', 'concert', 'music', 'abel tesfaye'],
        yesPrice: 0.43,
        noPrice: 0.57,
        volume24h: 198000,
        url: 'https://polymarket.com/event/coachella-weeknd',
        category: 'music',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-04-15',
    },
    {
        id: 'poly-grammy-sabrina',
        platform: 'polymarket',
        title: 'Will Sabrina Carpenter win a Grammy in 2026?',
        description: 'Resolves Yes if Sabrina Carpenter wins any Grammy Award at the 2026 ceremony.',
        keywords: ['sabrina carpenter', 'grammy', 'music', 'pop music', 'award', 'espresso'],
        yesPrice: 0.52,
        noPrice: 0.48,
        volume24h: 289000,
        url: 'https://polymarket.com/event/grammy-sabrina',
        category: 'music',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-02-28',
        oneDayPriceChange: 0.03,
    },
    {
        id: 'poly-kanye-album',
        platform: 'polymarket',
        title: 'Will Kanye West release an album in 2026?',
        description: 'Resolves Yes if Kanye West officially releases a studio album in 2026.',
        keywords: ['kanye west', 'ye', 'music', 'album', 'hip hop', 'rap', 'donda'],
        yesPrice: 0.39,
        noPrice: 0.61,
        volume24h: 312000,
        url: 'https://polymarket.com/event/kanye-album',
        category: 'music',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    // ── Social Media & Influencers ─────────────────────────────────────────────
    {
        id: 'poly-elon-x-ceo',
        platform: 'polymarket',
        title: 'Will Elon Musk step down as X CEO in 2026?',
        description: 'Resolves Yes if Elon Musk announces he is stepping down as CEO of X (Twitter) in 2026.',
        keywords: ['elon musk', 'twitter', 'x', 'social media', 'ceo', 'tech', 'musk'],
        yesPrice: 0.31,
        noPrice: 0.69,
        volume24h: 534000,
        url: 'https://polymarket.com/event/elon-x-ceo',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: -0.01,
    },
    {
        id: 'poly-tiktok-ban',
        platform: 'polymarket',
        title: 'Will TikTok be banned in the US in 2026?',
        description: 'Resolves Yes if TikTok is effectively banned or forced to shut down in the United States in 2026.',
        keywords: ['tiktok', 'ban', 'social media', 'bytedance', 'china', 'congress', 'app ban'],
        yesPrice: 0.27,
        noPrice: 0.73,
        volume24h: 678000,
        url: 'https://polymarket.com/event/tiktok-ban',
        category: 'technology',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: -0.04,
    },
    {
        id: 'poly-pokimane-retire',
        platform: 'polymarket',
        title: 'Will Pokimane retire from streaming in 2026?',
        description: 'Resolves Yes if Pokimane announces retirement from full-time streaming in 2026.',
        keywords: ['pokimane', 'twitch', 'streaming', 'content creator', 'streamer', 'gaming'],
        yesPrice: 0.19,
        noPrice: 0.81,
        volume24h: 167000,
        url: 'https://polymarket.com/event/pokimane-retire',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    {
        id: 'poly-xqc-deal',
        platform: 'polymarket',
        title: 'Will xQc sign a $100M+ streaming deal in 2026?',
        description: 'Resolves Yes if xQc publicly announces a streaming deal worth $100M or more in 2026.',
        keywords: ['xqc', 'streaming', 'twitch', 'kick', 'content creator', 'streamer', 'deal'],
        yesPrice: 0.23,
        noPrice: 0.77,
        volume24h: 245000,
        url: 'https://polymarket.com/event/xqc-deal',
        category: 'entertainment',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    // ── Space & Science ────────────────────────────────────────────────────────
    {
        id: 'poly-spacex-mars',
        platform: 'polymarket',
        title: 'Will SpaceX launch Starship to Mars in 2026?',
        description: 'Resolves Yes if SpaceX successfully launches a Starship mission to Mars in 2026.',
        keywords: ['spacex', 'starship', 'mars', 'elon musk', 'space', 'rocket', 'space exploration'],
        yesPrice: 0.21,
        noPrice: 0.79,
        volume24h: 489000,
        url: 'https://polymarket.com/event/spacex-mars',
        category: 'science',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.02,
    },
    {
        id: 'poly-agi-2026',
        platform: 'polymarket',
        title: 'Will AGI be achieved in 2026?',
        description: 'Resolves Yes if artificial general intelligence is credibly demonstrated by a major AI lab in 2026.',
        keywords: ['agi', 'artificial intelligence', 'ai', 'openai', 'deepmind', 'anthropic', 'machine learning'],
        yesPrice: 0.09,
        noPrice: 0.91,
        volume24h: 756000,
        url: 'https://polymarket.com/event/agi-2026',
        category: 'science',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    {
        id: 'poly-quantum-breakthrough',
        platform: 'polymarket',
        title: 'Will Google announce quantum supremacy in 2026?',
        description: 'Resolves Yes if Google announces a major quantum computing breakthrough in 2026.',
        keywords: ['quantum computing', 'google', 'quantum', 'computing', 'science', 'technology', 'willow'],
        yesPrice: 0.47,
        noPrice: 0.53,
        volume24h: 334000,
        url: 'https://polymarket.com/event/quantum-google',
        category: 'science',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.03,
    },
    {
        id: 'poly-nasa-artemis',
        platform: 'polymarket',
        title: 'Will NASA Artemis 3 launch in 2026?',
        description: 'Resolves Yes if NASA successfully launches the Artemis 3 moon mission in 2026.',
        keywords: ['nasa', 'artemis', 'moon', 'space', 'lunar', 'space exploration', 'apollo'],
        yesPrice: 0.34,
        noPrice: 0.66,
        volume24h: 278000,
        url: 'https://polymarket.com/event/artemis-3',
        category: 'science',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    // ── Food & Lifestyle ───────────────────────────────────────────────────────
    {
        id: 'poly-mcdonalds-all-day',
        platform: 'polymarket',
        title: 'Will McDonald\'s bring back all-day breakfast in 2026?',
        description: 'Resolves Yes if McDonald\'s officially announces the return of all-day breakfast in the US in 2026.',
        keywords: ['mcdonalds', 'breakfast', 'fast food', 'food', 'restaurant', 'mcmuffin'],
        yesPrice: 0.38,
        noPrice: 0.62,
        volume24h: 156000,
        url: 'https://polymarket.com/event/mcdonalds-breakfast',
        category: 'lifestyle',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    {
        id: 'poly-starbucks-union',
        platform: 'polymarket',
        title: 'Will Starbucks unionize 1000+ stores in 2026?',
        description: 'Resolves Yes if 1,000 or more Starbucks stores in the US unionize by end of 2026.',
        keywords: ['starbucks', 'union', 'labor', 'workers', 'coffee', 'sbux', 'unionization'],
        yesPrice: 0.42,
        noPrice: 0.58,
        volume24h: 223000,
        url: 'https://polymarket.com/event/starbucks-union',
        category: 'lifestyle',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    {
        id: 'poly-lab-grown-meat',
        platform: 'polymarket',
        title: 'Will lab-grown meat be sold in US supermarkets in 2026?',
        description: 'Resolves Yes if cultivated meat products are available for purchase in major US supermarkets in 2026.',
        keywords: ['lab grown meat', 'cultivated meat', 'food', 'meat', 'synthetic', 'alternative protein'],
        yesPrice: 0.56,
        noPrice: 0.44,
        volume24h: 298000,
        url: 'https://polymarket.com/event/lab-meat',
        category: 'lifestyle',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.04,
    },
    // ── Fashion & Beauty ───────────────────────────────────────────────────────
    {
        id: 'poly-met-gala-theme',
        platform: 'polymarket',
        title: 'Will the 2026 Met Gala theme be fashion-related?',
        description: 'Resolves Yes if the Met Gala 2026 theme is directly related to fashion history or design.',
        keywords: ['met gala', 'fashion', 'vogue', 'anna wintour', 'gala', 'celebrity', 'red carpet'],
        yesPrice: 0.73,
        noPrice: 0.27,
        volume24h: 187000,
        url: 'https://polymarket.com/event/met-gala',
        category: 'lifestyle',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-05-01',
    },
    {
        id: 'poly-balenciaga-comeback',
        platform: 'polymarket',
        title: 'Will Balenciaga regain pre-2022 brand value in 2026?',
        description: 'Resolves Yes if Balenciaga brand valuation returns to 2022 levels or higher by end of 2026.',
        keywords: ['balenciaga', 'fashion', 'luxury', 'brand', 'controversy', 'kering'],
        yesPrice: 0.29,
        noPrice: 0.71,
        volume24h: 145000,
        url: 'https://polymarket.com/event/balenciaga',
        category: 'lifestyle',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
    // ── Finance & Business ─────────────────────────────────────────────────────
    {
        id: 'poly-reddit-ipo',
        platform: 'polymarket',
        title: 'Will Reddit stock exceed $100 in 2026?',
        description: 'Resolves Yes if Reddit (RDDT) stock price exceeds $100 per share at any point in 2026.',
        keywords: ['reddit', 'stock', 'ipo', 'rddt', 'social media', 'wallstreetbets', 'finance'],
        yesPrice: 0.48,
        noPrice: 0.52,
        volume24h: 445000,
        url: 'https://polymarket.com/event/reddit-stock',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.02,
    },
    {
        id: 'poly-shein-ipo',
        platform: 'polymarket',
        title: 'Will Shein IPO in 2026?',
        description: 'Resolves Yes if Shein completes an initial public offering in 2026.',
        keywords: ['shein', 'ipo', 'fast fashion', 'ecommerce', 'china', 'fashion', 'retail'],
        yesPrice: 0.61,
        noPrice: 0.39,
        volume24h: 367000,
        url: 'https://polymarket.com/event/shein-ipo',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
        oneDayPriceChange: 0.05,
    },
    {
        id: 'poly-stripe-ipo',
        platform: 'polymarket',
        title: 'Will Stripe go public in 2026?',
        description: 'Resolves Yes if Stripe completes an IPO or direct listing in 2026.',
        keywords: ['stripe', 'ipo', 'fintech', 'payments', 'startup', 'finance', 'patrick collison'],
        yesPrice: 0.37,
        noPrice: 0.63,
        volume24h: 512000,
        url: 'https://polymarket.com/event/stripe-ipo',
        category: 'economics',
        lastUpdated: new Date().toISOString(),
        endDate: '2026-12-31',
    },
];
// Helper function to search markets by keywords
function searchMarkets(query) {
    const queryLower = query.toLowerCase();
    return mockMarkets.filter((market) => market.keywords.some((keyword) => queryLower.includes(keyword.toLowerCase())));
}

;// ./src/analysis/keyword-matcher.ts
// Keyword-based market matcher
// Uses word-boundary matching, synonym expansion, and phrase extraction

// ─── Stop words ──────────────────────────────────────────────────────────────
const STOP_WORDS = new Set([
    'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for',
    'of', 'with', 'by', 'from', 'as', 'is', 'was', 'are', 'were', 'be',
    'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
    'would', 'should', 'could', 'may', 'might', 'can', 'this', 'that',
    'these', 'those', 'i', 'you', 'he', 'she', 'it', 'we', 'they', 'them',
    'their', 'what', 'which', 'who', 'when', 'where', 'why', 'how', 'all',
    'just', 'so', 'than', 'too', 'very', 'not', 'no', 'yes',
    // Generic everyday words that are too ambiguous to be matching signals.
    // e.g. "sharing them with the world" must not match FIFA World Cup markets.
    // e.g. "this man just keeps..." must not match "Man City" markets.
    'world', 'cup', 'game', 'games', 'live', 'work', 'way', 'show', 'back',
    'know', 'good', 'big', 'take', 'top', 'open', 'run', 'real', 'right',
    'mean', 'only', 'even', 'well', 'off', 'look', 'find', 'going', 'come',
    'make', 'made', 'day', 'days', 'part', 'true', 'keep', 'left', 'try',
    'give', 'once', 'ever', 'much', 'many', 'other', 'every', 'again',
    'move', 'play', 'long', 'high', 'side', 'line', 'lead', 'role', 'hold',
    'plan', 'place', 'start', 'see', 'say', 'said', 'goes',
    // Pronouns / generic nouns that form compound sport names but are noise alone
    'man', 'men', 'city', 'united', 'new', 'old', 'final', 'league',
]);
// Domain-specific noise words that appear in nearly every financial/political tweet
// and produce false positives when used as matching signals
const DOMAIN_NOISE_WORDS = new Set([
    'market', 'markets', 'price', 'prices', 'trading', 'trade',
    'buy', 'sell', 'stock', 'stocks', 'invest', 'investing',
    'predict', 'prediction', 'odds', 'bet', 'betting', 'chance', 'probability',
    'likely', 'unlikely', 'bullish', 'bearish',
    'soon', 'today', 'tomorrow', 'week', 'month', 'year',
    'thread', 'breaking', 'update', 'report', 'says', 'said',
    'now', 'latest',
    // Additional noise words that cause false positives
    'people', 'thing', 'things', 'time', 'times', 'news', 'new',
    'next', 'last', 'first', 'second', 'third', 'another', 'some',
    'here', 'there', 'think', 'thought', 'thoughts', 'post', 'tweet',
    'twitter', 'follow', 'share', 'read', 'watch', 'check', 'via',
    'amp', 'quote', 'retweet', 'reply', 'comment', 'comments',
    'video', 'photo', 'image', 'link', 'article', 'story',
    'must', 'need', 'want', 'lol', 'lmao', 'wtf', 'omg', 'tbh',
]);
// ─── Synonym / alias map ─────────────────────────────────────────────────────
// Maps tweet tokens (what people write) → canonical market keywords
// Supports multi-word keys via bigram/trigram extraction
const SYNONYM_MAP = {
    // Fed / Monetary Policy
    'fed': ['federal reserve', 'fomc', 'interest rates'],
    'federal reserve': ['fed', 'fomc', 'interest rates'],
    'fomc': ['fed', 'federal reserve', 'interest rates'],
    'jerome powell': ['fed', 'federal reserve', 'fomc'],
    'powell': ['fed', 'federal reserve', 'fomc'],
    'janet yellen': ['treasury', 'fiscal policy'],
    'yellen': ['treasury', 'fiscal policy'],
    'rate hike': ['interest rates', 'fed', 'fomc'],
    'rate cut': ['interest rates', 'fed', 'fomc'],
    'interest rate': ['fed', 'fomc', 'monetary policy'],
    'basis points': ['interest rates', 'rate hike', 'rate cut'],
    'bps': ['basis points', 'interest rates'],
    'dot plot': ['fomc', 'fed', 'interest rates'],
    'quantitative easing': ['fed', 'monetary policy'],
    'qe': ['quantitative easing', 'fed'],
    // Economics
    'cpi': ['inflation', 'consumer price index'],
    'inflation': ['cpi', 'consumer price index', 'cost of living'],
    'pce': ['inflation', 'consumer spending'],
    'gdp': ['economic growth', 'recession'],
    'recession': ['gdp', 'economic downturn', 'contraction'],
    'unemployment': ['jobs', 'labor market', 'payrolls', 'jobless'],
    'nfp': ['nonfarm payrolls', 'jobs', 'unemployment'],
    'nonfarm payrolls': ['jobs', 'unemployment', 'labor market'],
    'payrolls': ['jobs', 'unemployment', 'labor market'],
    'layoffs': ['unemployment', 'jobs', 'labor market'],
    'sp500': ['s&p 500', 'stocks', 'equities'],
    's&p 500': ['sp500', 'stocks', 'equities'],
    's&p': ['sp500', 's&p 500', 'stocks'],
    'nasdaq': ['stocks', 'equities', 'tech stocks'],
    'dow': ['stocks', 'equities', 'dow jones'],
    'dow jones': ['dow', 'stocks', 'equities'],
    'yield curve': ['bonds', 'treasuries', 'interest rates'],
    'treasuries': ['bonds', 'yield curve', 'interest rates'],
    // Politics
    'potus': ['president', 'white house'],
    'white house': ['president', 'administration'],
    'gop': ['republican', 'republicans'],
    'rnc': ['republican', 'republicans'],
    'dnc': ['democrat', 'democrats'],
    'doge': ['spending cuts', 'government efficiency', 'dogecoin', 'crypto', 'meme coin'],
    'doj': ['justice department', 'attorney general'],
    'scotus': ['supreme court'],
    'supreme court': ['scotus'],
    'senate': ['congress', 'legislation'],
    'house': ['congress', 'legislation', 'house of representatives'],
    'congress': ['senate', 'legislation', 'house'],
    'executive order': ['president', 'administration', 'white house'],
    // Crypto
    'btc': ['bitcoin'],
    'bitcoin': ['btc', 'crypto'],
    'eth': ['ethereum'],
    'ethereum': ['eth', 'crypto'],
    'sol': ['solana'],
    'solana': ['sol', 'crypto'],
    'xrp': ['ripple'],
    'ripple': ['xrp'],
    'sec': ['securities', 'regulation', 'crypto regulation'],
    'gensler': ['sec', 'crypto regulation'],
    'etf': ['exchange traded fund', 'bitcoin etf', 'spot etf'],
    'spot etf': ['etf', 'bitcoin etf', 'sec'],
    'defi': ['decentralized finance', 'crypto'],
    'stablecoin': ['usdc', 'usdt', 'tether'],
    'usdc': ['stablecoin', 'crypto'],
    'usdt': ['stablecoin', 'tether', 'crypto'],
    'halving': ['bitcoin', 'btc', 'crypto'],
    'coinbase': ['crypto', 'bitcoin', 'exchange'],
    'binance': ['crypto', 'exchange'],
    // Ethereum ecosystem
    'l2': ['layer 2', 'ethereum', 'eth'],
    'layer2': ['layer 2', 'ethereum', 'eth'],
    'layer-2': ['layer 2', 'ethereum', 'eth'],
    'layer 2': ['ethereum', 'eth', 'scaling'],
    'web3': ['ethereum', 'eth', 'defi', 'crypto'],
    'dapp': ['ethereum', 'eth', 'defi'],
    'dapps': ['ethereum', 'eth', 'defi'],
    'gas fees': ['ethereum', 'eth'],
    'gas fee': ['ethereum', 'eth'],
    'gwei': ['ethereum', 'eth', 'gas fees'],
    'merge': ['ethereum', 'eth', 'proof of stake'],
    'proof of stake': ['ethereum', 'eth', 'staking'],
    'pos': ['proof of stake', 'ethereum', 'staking'],
    'staking': ['ethereum', 'eth', 'proof of stake'],
    'ens': ['ethereum', 'eth'],
    'nft': ['ethereum', 'eth', 'digital art'],
    'nfts': ['ethereum', 'eth', 'nft'],
    'polygon': ['ethereum', 'eth', 'layer 2'],
    'arbitrum': ['ethereum', 'eth', 'layer 2'],
    'optimism': ['ethereum', 'eth', 'layer 2'],
    'base': ['ethereum', 'eth', 'layer 2'],
    'vitalik': ['ethereum', 'eth', 'buterin'],
    'buterin': ['ethereum', 'eth', 'vitalik'],
    // Solana
    'phantom': ['solana', 'sol', 'crypto'],
    'pump fun': ['solana', 'sol', 'memecoin'],
    'memecoin': ['crypto', 'solana', 'doge'],
    'meme coin': ['crypto', 'solana', 'doge'],
    // Other crypto
    'dogecoin': ['doge', 'crypto'],
    'shib': ['shiba', 'crypto', 'memecoin'],
    'pepe': ['memecoin', 'crypto'],
    'altcoin': ['crypto', 'altcoins'],
    'altcoins': ['crypto', 'altcoin'],
    'bull run': ['crypto', 'bitcoin', 'btc'],
    'bear market': ['crypto', 'recession'],
    'crypto winter': ['crypto', 'bitcoin', 'bear market'],
    'on-chain': ['crypto', 'blockchain', 'defi'],
    'blockchain': ['crypto', 'ethereum', 'bitcoin'],
    'wallet': ['crypto', 'ethereum', 'bitcoin'],
    'metamask': ['ethereum', 'eth', 'defi', 'web3'],
    'kraken': ['crypto', 'exchange'],
    'ftx': ['crypto', 'exchange', 'sec'],
    'sbf': ['ftx', 'crypto', 'sec'],
    // Tech / AI
    'openai': ['ai', 'artificial intelligence', 'chatgpt', 'gpt', 'llm'],
    'chatgpt': ['openai', 'ai', 'llm'],
    'gpt': ['openai', 'chatgpt', 'ai', 'llm'],
    'gpt-4': ['openai', 'chatgpt', 'ai', 'llm'],
    'anthropic': ['ai', 'claude', 'llm', 'artificial intelligence'],
    'claude': ['anthropic', 'ai', 'llm'],
    'gemini': ['google', 'ai', 'llm'],
    'llm': ['ai', 'artificial intelligence'],
    'agi': ['artificial general intelligence', 'ai'],
    'sam altman': ['openai', 'ai', 'chatgpt'],
    'altman': ['openai', 'ai', 'chatgpt'],
    'jensen huang': ['nvidia', 'nvda', 'gpu', 'ai chips'],
    'huang': ['nvidia', 'nvda', 'gpu'],
    'nvda': ['nvidia'],
    'nvidia': ['nvda', 'gpu', 'ai chips', 'semiconductors'],
    'gpu': ['nvidia', 'nvda', 'chips'],
    'chips': ['semiconductors', 'nvidia', 'tsmc'],
    'semiconductors': ['chips', 'nvidia', 'tsmc', 'intel'],
    'tsmc': ['semiconductors', 'chips', 'taiwan'],
    'aapl': ['apple'],
    'apple': ['aapl', 'iphone', 'tim cook'],
    'tim cook': ['apple', 'aapl'],
    'msft': ['microsoft'],
    'microsoft': ['msft'],
    'googl': ['google', 'alphabet'],
    'google': ['googl', 'alphabet'],
    'alphabet': ['google', 'googl'],
    'meta': ['facebook', 'instagram'],
    'big tech': ['apple', 'google', 'microsoft', 'meta', 'amazon'],
    'faang': ['big tech', 'apple', 'google', 'meta', 'amazon'],
    'eu ai act': ['ai regulation', 'artificial intelligence', 'regulation'],
    // Geopolitics
    'nato': ['alliance', 'military', 'europe', 'ukraine'],
    'ukraine': ['russia', 'war', 'nato', 'zelensky'],
    'zelensky': ['ukraine', 'russia'],
    'putin': ['russia', 'ukraine', 'kremlin'],
    'kremlin': ['russia', 'putin'],
    'prc': ['china', 'beijing'],
    'beijing': ['china', 'xi jinping'],
    'xi jinping': ['china', 'beijing'],
    'xi': ['china', 'xi jinping', 'beijing'],
    'taiwan': ['china', 'semiconductors', 'tsmc'],
    'gaza': ['israel', 'hamas', 'middle east', 'conflict'],
    'israel': ['gaza', 'hamas', 'middle east'],
    'ceasefire': ['ukraine', 'russia', 'peace', 'conflict'],
    'peace deal': ['ukraine', 'russia', 'peace agreement', 'ceasefire'],
    // Sports
    'nfl': ['football', 'super bowl'],
    'nba': ['basketball'],
    'mlb': ['baseball'],
    'nhl': ['hockey'],
    'super bowl': ['nfl', 'football'],
    'march madness': ['ncaa', 'basketball'],
    'world cup': ['soccer', 'football', 'fifa'],
    'fifa': ['soccer', 'world cup'],
    'champions league': ['soccer', 'football', 'europe', 'uefa', 'ucl'],
    'ucl': ['champions league', 'soccer', 'europe', 'uefa'],
    'europa league': ['soccer', 'football', 'europe', 'uefa'],
    'premier league': ['soccer', 'football', 'england', 'epl'],
    'epl': ['premier league', 'soccer', 'england'],
    'la liga': ['soccer', 'football', 'spain'],
    'serie a': ['soccer', 'football', 'italy'],
    'bundesliga': ['soccer', 'football', 'germany'],
    'man city': ['manchester city', 'soccer', 'premier league', 'champions league'],
    'man united': ['manchester united', 'soccer', 'premier league'],
    'manchester city': ['man city', 'soccer', 'premier league', 'champions league'],
    'manchester united': ['man united', 'soccer', 'premier league'],
    'arsenal': ['soccer', 'premier league', 'england'],
    'liverpool': ['soccer', 'premier league', 'england'],
    'chelsea': ['soccer', 'premier league', 'england'],
    'tottenham': ['soccer', 'premier league', 'spurs'],
    'real madrid': ['soccer', 'la liga', 'champions league'],
    'barcelona': ['soccer', 'la liga', 'spain'],
    'psg': ['paris saint germain', 'soccer', 'france'],
    'inter milan': ['soccer', 'serie a', 'italy'],
    'fa cup': ['soccer', 'england', 'football'],
    'ufc': ['mma', 'fighting', 'sports'],
    'mahomes': ['chiefs', 'kansas city', 'nfl', 'super bowl'],
    'patrick mahomes': ['chiefs', 'kansas city', 'nfl', 'super bowl'],
    'celtics': ['boston', 'nba', 'basketball'],
    'lakers': ['los angeles', 'nba', 'basketball'],
    // Climate / Energy
    'crude': ['oil', 'wti', 'energy'],
    'wti': ['oil', 'crude', 'energy'],
    'brent': ['oil', 'crude', 'energy'],
    'opec': ['oil', 'energy', 'production cuts'],
    'ev': ['electric vehicle', 'tesla', 'clean energy'],
    'electric vehicle': ['ev', 'tesla'],
    'tesla': ['ev', 'electric vehicle', 'elon musk'],
    'elon musk': ['tesla', 'spacex', 'twitter', 'x', 'doge'],
    'musk': ['tesla', 'elon musk', 'spacex', 'doge'],
    'elon': ['elon musk', 'tesla', 'spacex', 'doge'],
    'net zero': ['climate', 'emissions', 'carbon'],
    'paris agreement': ['climate', 'emissions', 'net zero'],
    'carbon': ['climate', 'emissions', 'carbon tax'],
    'global warming': ['climate change', 'climate', 'temperature'],
    'climate change': ['global warming', 'climate', 'emissions'],
    // Trade / Tariffs (2025 dominant news topic)
    'tariff': ['trade war', 'trade deal', 'import tax', 'china trade', 'trade'],
    'tariffs': ['tariff', 'trade war', 'trade deal', 'import tax'],
    'trade war': ['tariff', 'tariffs', 'china', 'trade deal'],
    'trade deal': ['tariff', 'tariffs', 'trade war', 'trade'],
    'import tax': ['tariff', 'tariffs', 'trade'],
    'sanctions': ['trade', 'russia', 'china', 'iran'],
    // Immigration / Border
    'deportation': ['immigration', 'border', 'ice', 'migrants', 'undocumented'],
    'deport': ['deportation', 'immigration', 'ice', 'border'],
    'immigration': ['border', 'deportation', 'ice', 'migrants'],
    'border': ['immigration', 'deportation', 'wall'],
    'migrants': ['immigration', 'border', 'deportation'],
    'ice': ['deportation', 'immigration', 'border'],
    // AI Models & Companies (2025/2026)
    'deepseek': ['ai', 'llm', 'china ai', 'artificial intelligence'],
    'llama': ['meta', 'ai', 'llm', 'open source ai'],
    'mistral': ['ai', 'llm', 'artificial intelligence'],
    'grok': ['xai', 'elon musk', 'ai', 'llm'],
    'xai': ['grok', 'elon musk', 'ai'],
    'perplexity': ['ai', 'search', 'llm'],
    'cursor': ['ai', 'coding', 'developer tools'],
    'copilot': ['microsoft', 'msft', 'ai', 'github'],
    'o1': ['openai', 'chatgpt', 'ai', 'reasoning'],
    'o3': ['openai', 'chatgpt', 'ai', 'reasoning'],
    // Specific people (2025)
    'trump': ['president', 'potus', 'administration', 'gop', 'republican'],
    'donald trump': ['trump', 'potus', 'president', 'republican'],
    'biden': ['president', 'potus', 'democrat', 'administration'],
    'harris': ['democrat', 'kamala', 'vice president'],
    'marco rubio': ['senate', 'republican', 'secretary of state'],
    'rfk': ['health', 'vaccines', 'kennedy'],
    'vivek': ['doge', 'republican', 'government efficiency'],
    // Stocks / Companies (2025)
    'palantir': ['pltr', 'data analytics', 'defense'],
    'pltr': ['palantir'],
    'saylor': ['bitcoin', 'btc', 'microstrategy', 'mstr'],
    'microstrategy': ['bitcoin', 'btc', 'mstr', 'saylor'],
    'mstr': ['microstrategy', 'bitcoin', 'btc'],
    'blackrock': ['etf', 'bitcoin etf', 'institutional'],
    'robinhood': ['stocks', 'crypto', 'retail investing'],
    'ipo': ['stocks', 'listing', 'public offering'],
    // Geopolitics / Countries
    'japan': ['japanese', 'yen', 'nikkei', 'jpy'],
    'japanese': ['japan', 'yen'],
    'china': ['chinese', 'prc', 'beijing', 'xi'],
    'india': ['modi', 'rupee', 'bse'],
    'germany': ['german', 'euro', 'bund', 'europe'],
    'uk': ['britain', 'gbp', 'pound', 'boe'],
    'iran': ['nuclear', 'sanctions', 'middle east'],
    'north korea': ['kim jong un', 'nuclear', 'missiles'],
    // More crypto (2025)
    'sui': ['crypto', 'layer 1'],
    'apt': ['aptos', 'crypto', 'layer 1'],
    'aptos': ['apt', 'crypto', 'layer 1'],
    'ton': ['telegram', 'crypto'],
    'bnb': ['binance', 'crypto'],
    'avax': ['avalanche', 'crypto'],
    'avalanche': ['avax', 'crypto'],
    'trump coin': ['crypto', 'meme coin'],
    'meme': ['memecoin', 'crypto', 'doge'],
    'stablecoin bill': ['stablecoin', 'crypto regulation', 'congress'],
    'crypto bill': ['crypto regulation', 'sec', 'congress'],
    'strategic reserve': ['bitcoin', 'btc', 'crypto'],
    // ── Wall Street / Banks / Institutions ───────────────────────────────────
    'goldman sachs': ['bitcoin', 'crypto', 'bank', 'institutional', 'wall street'],
    'goldman': ['goldman sachs', 'bank', 'wall street'],
    'david solomon': ['goldman sachs', 'bitcoin', 'bank'],
    'solomon': ['goldman sachs', 'bank', 'bitcoin'],
    'jpmorgan': ['bank', 'jamie dimon', 'financial', 'wall street'],
    'jp morgan': ['jpmorgan', 'bank', 'jamie dimon'],
    'jamie dimon': ['jpmorgan', 'bank', 'bitcoin'],
    'dimon': ['jpmorgan', 'bank', 'jamie dimon'],
    'morgan stanley': ['bank', 'wall street', 'institutional'],
    'bank of america': ['bank', 'bofa', 'financial'],
    'bofa': ['bank of america', 'bank'],
    'wells fargo': ['bank', 'financial'],
    'citigroup': ['bank', 'citi', 'financial'],
    'citi': ['citigroup', 'bank'],
    'hsbc': ['bank', 'financial'],
    'wall street': ['banks', 'financial', 'stocks', 'institutional'],
    'larry fink': ['blackrock', 'etf', 'bitcoin etf', 'institutional'],
    'fink': ['blackrock', 'etf', 'bitcoin etf'],
    'ray dalio': ['bridgewater', 'hedge fund', 'investment'],
    'dalio': ['bridgewater', 'investment'],
    'warren buffett': ['berkshire', 'stocks', 'investment'],
    'buffett': ['berkshire', 'stocks'],
    'berkshire': ['warren buffett', 'stocks', 'insurance'],
    'citadel': ['ken griffin', 'market maker', 'hedge fund'],
    'ken griffin': ['citadel', 'hedge fund'],
    'bridgewater': ['ray dalio', 'hedge fund'],
    'ubs': ['bank', 'switzerland', 'financial'],
    'deutsche bank': ['bank', 'german', 'financial'],
    'standard chartered': ['bank', 'financial'],
    // ── Institutional crypto adoption ─────────────────────────────────────────
    'fidelity': ['bitcoin etf', 'fbtc', 'etf', 'institutional'],
    'fbtc': ['fidelity', 'bitcoin etf', 'etf'],
    'ibit': ['blackrock', 'bitcoin etf', 'etf'],
    'gbtc': ['grayscale', 'bitcoin etf', 'crypto'],
    'grayscale': ['gbtc', 'bitcoin etf', 'crypto', 'etf'],
    'bitwise': ['bitcoin etf', 'etf', 'crypto'],
    'ark invest': ['cathie wood', 'etf', 'bitcoin etf'],
    'cathie wood': ['ark invest', 'etf', 'bitcoin'],
    'cathie': ['ark invest', 'bitcoin etf'],
    'institutional adoption': ['bitcoin', 'crypto', 'etf'],
    'institutional': ['bitcoin', 'etf', 'wall street'],
    'treasury': ['bitcoin', 'strategic reserve', 'government'],
    // ── Crypto news phrases ───────────────────────────────────────────────────
    'hodl': ['bitcoin', 'btc', 'crypto'],
    'holds bitcoin': ['bitcoin', 'btc', 'crypto'],
    'owns bitcoin': ['bitcoin', 'btc', 'crypto'],
    'buys bitcoin': ['bitcoin', 'btc', 'crypto'],
    'bought bitcoin': ['bitcoin', 'btc', 'crypto'],
    'adding bitcoin': ['bitcoin', 'btc', 'crypto'],
    'digital gold': ['bitcoin', 'btc', 'store of value'],
    'store of value': ['bitcoin', 'btc', 'gold'],
    'proof of work': ['bitcoin', 'btc', 'mining'],
    'pow': ['proof of work', 'bitcoin', 'mining'],
    'mining': ['bitcoin', 'btc', 'hashrate'],
    'hashrate': ['bitcoin', 'btc', 'mining'],
    'satoshi': ['bitcoin', 'btc'],
    'sats': ['bitcoin', 'btc', 'satoshi'],
    'lightning': ['bitcoin', 'btc', 'lightning network'],
    'ordinals': ['bitcoin', 'btc', 'nft'],
    'runes': ['bitcoin', 'btc'],
    'taproot': ['bitcoin', 'btc'],
    'all time high': ['bitcoin', 'crypto', 'stocks', 'ath'],
    'ath': ['all time high', 'bitcoin', 'crypto'],
    'all-time high': ['bitcoin', 'crypto', 'ath'],
    'new high': ['bitcoin', 'crypto', 'stocks'],
    '100k': ['bitcoin', 'btc', 'price target'],
    '150k': ['bitcoin', 'btc', 'price target'],
    '200k': ['bitcoin', 'btc', 'price target'],
    // ── Politics / Executive branch (2025-2026) ───────────────────────────────
    'scott bessent': ['treasury', 'fiscal', 'secretary treasury'],
    'bessent': ['treasury', 'fiscal policy'],
    'howard lutnick': ['commerce', 'cantor fitzgerald', 'trade'],
    'lutnick': ['commerce', 'trade'],
    'peter navarro': ['tariff', 'trade war', 'china'],
    'navarro': ['tariff', 'trade war'],
    'robert kennedy': ['rfk', 'health', 'vaccines'],
    'department of government efficiency': ['doge', 'spending cuts'],
    // ── Tech companies / AI (2025-2026) ──────────────────────────────────────
    'amazon': ['amzn', 'aws', 'cloud', 'bezos'],
    'amzn': ['amazon'],
    'jeff bezos': ['amazon', 'amzn'],
    'bezos': ['amazon', 'amzn'],
    'andy jassy': ['amazon', 'aws'],
    'spacex': ['elon musk', 'rockets', 'starship'],
    'starship': ['spacex', 'elon musk'],
    'starlink': ['spacex', 'elon musk', 'satellite'],
    'mark zuckerberg': ['meta', 'facebook', 'instagram'],
    'zuckerberg': ['meta', 'facebook', 'ai'],
    'sundar pichai': ['google', 'alphabet', 'ai'],
    'satya nadella': ['microsoft', 'msft', 'ai'],
    'intel': ['semiconductors', 'chips'],
    'amd': ['semiconductors', 'chips', 'gpu'],
    'qualcomm': ['semiconductors', 'chips', 'mobile'],
    'arm': ['semiconductors', 'chips'],
    // ── Nvidia chip architectures & products ─────────────────────────────────
    'jensen': ['jensen huang', 'nvidia', 'nvda', 'gpu'],
    'blackwell': ['nvidia', 'nvda', 'gpu', 'ai chips'],
    'hopper': ['nvidia', 'nvda', 'gpu', 'h100'],
    'h100': ['nvidia', 'nvda', 'gpu', 'ai chips'],
    'h200': ['nvidia', 'nvda', 'gpu', 'ai chips'],
    'b100': ['nvidia', 'nvda', 'gpu', 'blackwell'],
    'b200': ['nvidia', 'nvda', 'gpu', 'blackwell'],
    'gb200': ['nvidia', 'nvda', 'blackwell', 'gpu'],
    'nvlink': ['nvidia', 'nvda', 'gpu'],
    'cuda': ['nvidia', 'nvda', 'gpu'],
    'data center': ['nvidia', 'ai', 'semiconductors', 'chips'],
    'new chips': ['nvidia', 'semiconductors', 'gpu', 'ai chips'],
    'ai chip': ['nvidia', 'nvda', 'gpu', 'semiconductors'],
    'ai chips': ['nvidia', 'nvda', 'gpu', 'semiconductors'],
    'chip ban': ['semiconductors', 'nvidia', 'china', 'export controls'],
    'export controls': ['semiconductors', 'nvidia', 'china', 'chips'],
    'foundry': ['semiconductors', 'tsmc', 'chips'],
    // New AI model releases
    'claude 4': ['anthropic', 'ai', 'claude', 'llm'],
    'claude 3': ['anthropic', 'ai', 'claude', 'llm'],
    'gpt 5': ['openai', 'chatgpt', 'ai', 'llm'],
    'gpt-5': ['openai', 'chatgpt', 'ai', 'llm'],
    'reasoning model': ['ai', 'openai', 'anthropic', 'llm'],
    'inference': ['ai', 'llm', 'nvidia', 'data center'],
    // ── Macro / Global economy ────────────────────────────────────────────────
    'ecb': ['european central bank', 'euro', 'interest rates'],
    'european central bank': ['ecb', 'euro', 'interest rates'],
    'boe': ['bank of england', 'pound', 'interest rates'],
    'bank of england': ['boe', 'pound', 'interest rates'],
    'pboc': ['china', 'yuan', 'interest rates'],
    'boj': ['bank of japan', 'yen', 'japan'],
    'bank of japan': ['boj', 'yen', 'japan'],
    'dollar': ['usd', 'dxy', 'currency'],
    'dxy': ['dollar', 'usd', 'currency'],
    'usd': ['dollar', 'dxy'],
    'euro': ['eur', 'ecb', 'europe'],
    'eur': ['euro', 'ecb'],
    'yen': ['jpy', 'japan', 'boj'],
    'jpy': ['yen', 'japan'],
    'yuan': ['cny', 'rmb', 'china'],
    'gold': ['xau', 'precious metals', 'store of value', 'commodity'],
    'xau': ['gold', 'precious metals'],
    'silver': ['xag', 'precious metals', 'commodity'],
    'commodities': ['gold', 'oil', 'energy', 'agriculture'],
    'housing market': ['real estate', 'mortgage', 'fed'],
    'mortgage': ['housing market', 'real estate', 'interest rates', 'fed'],
    'real estate': ['housing market', 'mortgage'],
    'debt ceiling': ['congress', 'fiscal', 'treasury'],
    'default': ['debt', 'treasury', 'bonds'],
    'bonds': ['treasuries', 'yield', 'interest rates'],
    'yield': ['bonds', 'treasuries', 'interest rates'],
    // ── Sports / Entertainment (expanded) ────────────────────────────────────
    'chiefs': ['kansas city', 'nfl', 'mahomes', 'super bowl'],
    'eagles': ['philadelphia', 'nfl', 'super bowl'],
    'rams': ['los angeles', 'nfl', 'super bowl'],
    'bills': ['buffalo', 'nfl', 'super bowl'],
    'warriors': ['golden state', 'nba', 'basketball'],
    'heat': ['miami', 'nba', 'basketball'],
    'knicks': ['new york', 'nba', 'basketball'],
    'lebron': ['lakers', 'nba', 'basketball'],
    'curry': ['warriors', 'nba', 'basketball'],
    'messi': ['soccer', 'football', 'inter miami'],
    'ronaldo': ['soccer', 'football', 'cr7'],
    'wimbledon': ['tennis', 'grand slam'],
    'us open': ['tennis', 'grand slam'],
    'masters': ['golf', 'augusta'],
    'oscars': ['academy awards', 'movies', 'film'],
    'academy awards': ['oscars', 'movies', 'film'],
    'grammy': ['music', 'awards'],
    'emmys': ['tv', 'television', 'awards'],
    // ── Geopolitics (extended) ────────────────────────────────────────────────
    'middle east': ['israel', 'gaza', 'iran', 'saudi'],
    'saudi': ['saudi arabia', 'oil', 'opec'],
    'saudi arabia': ['saudi', 'oil', 'opec'],
    'hamas': ['gaza', 'israel', 'middle east'],
    'hezbollah': ['israel', 'middle east', 'iran'],
    'kim jong un': ['north korea', 'nuclear', 'missiles'],
    'kim': ['north korea', 'nuclear'],
    'modi': ['india', 'bjp'],
    'macron': ['france', 'europe', 'eu'],
    'sunak': ['uk', 'britain'],
    'scholz': ['germany', 'german', 'eu'],
    'europe': ['eu', 'european', 'ecb'],
    'eu': ['europe', 'european union'],
    'africa': ['emerging markets'],
    'latin america': ['emerging markets'],
    // ── Anime & Japanese Animation ────────────────────────────────────────────
    'anime': ['japanese animation', 'manga', 'crunchyroll', 'funimation'],
    'manga': ['anime', 'japanese animation', 'shonen jump'],
    'aot': ['attack on titan', 'shingeki no kyojin', 'anime'],
    'attack on titan': ['aot', 'shingeki no kyojin', 'anime', 'mappa'],
    'shingeki no kyojin': ['attack on titan', 'aot', 'anime'],
    'csm': ['chainsaw man', 'anime', 'manga'],
    'chainsaw man': ['csm', 'anime', 'manga', 'mappa'],
    'demon slayer': ['kimetsu no yaiba', 'anime', 'ufotable'],
    'kimetsu no yaiba': ['demon slayer', 'anime'],
    'my hero academia': ['mha', 'boku no hero', 'anime', 'manga'],
    'mha': ['my hero academia', 'boku no hero', 'anime'],
    'boku no hero': ['my hero academia', 'mha', 'anime'],
    'one piece': ['anime', 'manga', 'luffy', 'eiichiro oda'],
    'luffy': ['one piece', 'anime'],
    'naruto': ['anime', 'manga', 'shonen jump'],
    'bleach': ['anime', 'manga', 'shonen jump'],
    'dragon ball': ['anime', 'manga', 'dbz', 'goku'],
    'dbz': ['dragon ball', 'anime'],
    'goku': ['dragon ball', 'anime'],
    'jujutsu kaisen': ['jjk', 'anime', 'manga', 'mappa'],
    'jjk': ['jujutsu kaisen', 'anime'],
    'spy x family': ['anime', 'manga'],
    'studio ghibli': ['ghibli', 'anime', 'miyazaki', 'japanese animation'],
    'ghibli': ['studio ghibli', 'anime', 'miyazaki'],
    'miyazaki': ['hayao miyazaki', 'studio ghibli', 'anime'],
    'hayao miyazaki': ['miyazaki', 'studio ghibli', 'ghibli', 'anime'],
    'totoro': ['studio ghibli', 'miyazaki', 'anime'],
    'spirited away': ['studio ghibli', 'miyazaki', 'anime'],
    'mappa': ['anime', 'animation studio', 'attack on titan', 'jujutsu kaisen'],
    'ufotable': ['anime', 'animation studio', 'demon slayer'],
    'toei': ['anime', 'animation studio', 'one piece', 'dragon ball'],
    'bones': ['anime', 'animation studio', 'my hero academia'],
    'crunchyroll': ['anime', 'streaming', 'funimation', 'sony'],
    'funimation': ['anime', 'streaming', 'crunchyroll'],
    'shonen jump': ['manga', 'anime', 'japanese comics'],
    'webtoon': ['manga', 'comics', 'korean comics'],
    'manhwa': ['korean comics', 'manga', 'webtoon'],
    // ── Content Creation & Creator Economy ────────────────────────────────────
    'tiktok': ['short form', 'social media', 'bytedance', 'content creator', 'influencer'],
    'tiktoker': ['tiktok', 'content creator', 'influencer'],
    'youtube shorts': ['shorts', 'youtube', 'short form', 'content creator'],
    'shorts': ['youtube shorts', 'short form', 'youtube'],
    'reels': ['instagram reels', 'instagram', 'short form', 'meta'],
    'instagram reels': ['reels', 'instagram', 'short form'],
    'content creator': ['creator', 'influencer', 'youtuber', 'tiktoker', 'streamer'],
    'creator': ['content creator', 'influencer', 'youtuber'],
    'influencer': ['content creator', 'creator', 'social media'],
    'youtuber': ['youtube', 'content creator', 'creator'],
    'streamer': ['twitch', 'content creator', 'live stream'],
    'mrbeast': ['youtube', 'content creator', 'jimmy donaldson'],
    'jimmy donaldson': ['mrbeast', 'youtube'],
    'creator economy': ['content creator', 'influencer', 'monetization'],
    'monetization': ['creator economy', 'content creator', 'revenue'],
    'subscribers': ['youtube', 'content creator', 'followers'],
    'followers': ['social media', 'influencer', 'subscribers'],
    'views': ['youtube', 'tiktok', 'content creator'],
    'viral': ['tiktok', 'youtube', 'social media', 'trending'],
    'trending': ['viral', 'social media', 'tiktok'],
    'edits': ['video editing', 'content creation', 'editing'],
    'edit': ['video editing', 'editing', 'content creation'],
    'video editing': ['editing', 'content creation', 'premiere', 'final cut'],
    'editing': ['video editing', 'content creation'],
    'clawdbots': ['ai', 'ai bots', 'automation', 'content creation'],
    'ai bots': ['ai', 'automation', 'bots'],
    'bots': ['automation', 'ai bots'],
    // ── Streaming Platforms ────────────────────────────────────────────────────
    'twitch': ['streaming', 'amazon', 'live stream', 'content creator'],
    'live stream': ['streaming', 'twitch', 'youtube'],
    'streaming': ['netflix', 'twitch', 'youtube', 'content'],
    'netflix': ['streaming', 'content', 'series', 'movies'],
    'hulu': ['streaming', 'content', 'disney'],
    'disney plus': ['streaming', 'disney', 'content'],
    'disney+': ['disney plus', 'streaming', 'disney'],
    'hbo max': ['streaming', 'warner bros', 'content'],
    'prime video': ['streaming', 'amazon', 'content'],
    'paramount plus': ['streaming', 'paramount', 'content'],
    // ── AI Video & Content Tools ───────────────────────────────────────────────
    'sora': ['openai', 'ai video', 'video generation', 'ai'],
    'runway': ['ai video', 'video generation', 'generative ai'],
    'pika': ['ai video', 'video generation', 'generative ai'],
    'midjourney': ['ai', 'generative ai', 'ai art', 'image generation'],
    'stable diffusion': ['ai', 'generative ai', 'ai art', 'image generation'],
    'ai video': ['sora', 'runway', 'pika', 'generative ai', 'video generation'],
    'video generation': ['ai video', 'sora', 'runway', 'generative ai'],
    'ai art': ['generative ai', 'midjourney', 'stable diffusion'],
    'ai animation': ['ai video', 'animation', 'generative ai'],
    'generative ai': ['ai', 'ai video', 'ai art', 'diffusion'],
    // ── Film & Movies ──────────────────────────────────────────────────────────
    'film': ['movie', 'cinema', 'box office', 'hollywood'],
    'movie': ['film', 'cinema', 'box office'],
    'cinema': ['film', 'movie', 'theater'],
    'box office': ['movie', 'film', 'revenue', 'theater'],
    'hollywood': ['film', 'movie', 'entertainment'],
    'cartoon': ['animation', 'animated', 'cartoon edits'],
    'animation': ['animated', 'cartoon', 'anime'],
    'animated': ['animation', 'cartoon'],
    'pixar': ['animation', 'disney', 'animated film'],
    'dreamworks': ['animation', 'animated film'],
    // ── Gaming (expanded coverage) ────────────────────────────────────────────
    'gta': ['gta 6', 'grand theft auto', 'rockstar', 'gaming'],
    'gta 6': ['gta', 'grand theft auto', 'rockstar', 'gaming', 'video game'],
    'gta vi': ['gta 6', 'gta', 'grand theft auto', 'rockstar'],
    'grand theft auto': ['gta', 'gta 6', 'rockstar', 'gaming'],
    'rockstar': ['gta', 'gta 6', 'gaming', 'take two'],
    'take two': ['rockstar', 'gta', 'gaming'],
    'elden ring': ['fromsoftware', 'souls', 'gaming', 'rpg', 'dlc'],
    'fromsoftware': ['elden ring', 'dark souls', 'gaming', 'souls'],
    'souls': ['elden ring', 'dark souls', 'fromsoftware', 'gaming'],
    'dark souls': ['fromsoftware', 'souls', 'elden ring', 'gaming'],
    'league of legends': ['lol', 'riot games', 'esports', 'moba', 'gaming'],
    'lol': ['league of legends', 'esports', 'riot games', 'gaming'],
    'riot games': ['league of legends', 'valorant', 'gaming', 'esports'],
    'faker': ['league of legends', 'lol', 't1', 'esports'],
    't1': ['league of legends', 'faker', 'esports', 'korea'],
    'valorant': ['riot games', 'fps', 'esports', 'gaming', 'tac shooter'],
    'sentinels': ['valorant', 'esports', 'tenz', 'gaming'],
    'tenz': ['sentinels', 'valorant', 'esports'],
    'nintendo': ['switch', 'switch 2', 'gaming', 'console', 'zelda', 'mario'],
    'switch': ['nintendo', 'switch 2', 'gaming', 'console'],
    'switch 2': ['nintendo', 'switch', 'gaming', 'console', 'next gen'],
    'zelda': ['nintendo', 'switch', 'gaming', 'tears of the kingdom'],
    'mario': ['nintendo', 'switch', 'gaming', 'super mario'],
    'pokemon': ['nintendo', 'switch', 'gaming', 'game freak'],
    'minecraft': ['mojang', 'microsoft', 'sandbox', 'gaming', 'video game'],
    'mojang': ['minecraft', 'microsoft', 'gaming'],
    'hollow knight': ['silksong', 'indie game', 'metroidvania', 'team cherry'],
    'silksong': ['hollow knight', 'indie game', 'metroidvania', 'gaming'],
    'indie game': ['gaming', 'indie', 'video game'],
    'esports': ['gaming', 'competitive', 'tournament', 'league'],
    'gaming': ['video game', 'esports', 'gamer', 'console'],
    'gamer': ['gaming', 'video game', 'esports'],
    'console': ['gaming', 'playstation', 'xbox', 'nintendo'],
    'playstation': ['ps5', 'sony', 'gaming', 'console'],
    'ps5': ['playstation', 'sony', 'gaming', 'console'],
    'xbox': ['microsoft', 'gaming', 'console'],
    // ── Music (expanded coverage) ─────────────────────────────────────────────
    'taylor swift': ['music', 'pop', 'swifties', 'eras tour', 'album'],
    'swifties': ['taylor swift', 'music', 'fandom'],
    'eras tour': ['taylor swift', 'tour', 'concert', 'music'],
    'beyonce': ['music', 'pop', 'renaissance', 'tour', 'beyoncé'],
    'beyoncé': ['beyonce', 'music', 'pop'],
    'renaissance': ['beyonce', 'music', 'album'],
    'the weeknd': ['music', 'pop', 'r&b', 'abel tesfaye'],
    'abel tesfaye': ['the weeknd', 'music'],
    'coachella': ['music festival', 'festival', 'music', 'concert'],
    'music festival': ['coachella', 'concert', 'music', 'tour'],
    'festival': ['music festival', 'concert', 'music'],
    'sabrina carpenter': ['music', 'pop', 'singer', 'espresso'],
    'espresso': ['sabrina carpenter', 'music', 'song'],
    'ye': ['kanye west', 'kanye', 'music', 'rap', 'hip hop'],
    'concert': ['music', 'tour', 'live music', 'show'],
    'tour': ['concert', 'music', 'live music'],
    'album': ['music', 'release', 'new album'],
    'single': ['music', 'song', 'release'],
    'collaboration': ['music', 'collab', 'feature'],
    'collab': ['collaboration', 'music', 'feature'],
    // ── Social Media & Streaming ──────────────────────────────────────────────
    'kick': ['streaming', 'xqc', 'stake', 'content creator'],
    'pokimane': ['twitch', 'streaming', 'content creator', 'offlinetv'],
    'xqc': ['twitch', 'kick', 'streaming', 'streamer', 'content creator'],
    'mcdonalds': ['fast food', 'breakfast', 'restaurant', 'mcdonald'],
    'mcdonald': ['mcdonalds', 'fast food'],
    'starbucks': ['coffee', 'sbux', 'cafe', 'union'],
    'sbux': ['starbucks', 'coffee'],
    'fast food': ['mcdonalds', 'burger king', 'wendys', 'restaurant'],
    'restaurant': ['fast food', 'dining', 'food'],
    'shein': ['fast fashion', 'ecommerce', 'fashion', 'retail'],
    'balenciaga': ['fashion', 'luxury', 'brand', 'designer'],
    'met gala': ['fashion', 'vogue', 'anna wintour', 'red carpet'],
    'reddit': ['social media', 'rddt', 'stock', 'wallstreetbets'],
    'wallstreetbets': ['reddit', 'wsb', 'stocks', 'meme stock'],
    'wsb': ['wallstreetbets', 'reddit', 'stocks'],
};
// ─── Utility functions ───────────────────────────────────────────────────────
/** Returns true if a character is a word character (letter, digit, apostrophe) */
function isWordChar(ch) {
    const code = ch.charCodeAt(0);
    return ((code >= 97 && code <= 122) || // a-z
        (code >= 65 && code <= 90) || // A-Z
        (code >= 48 && code <= 57) || // 0-9
        code === 39 // apostrophe
    );
}
/**
 * Checks whether `term` appears in `text` as a whole word (respects word boundaries).
 * Avoids creating new RegExp objects per call for performance.
 */
function hasWordBoundaryMatch(text, term) {
    const termLower = term.toLowerCase();
    const textLower = text.toLowerCase();
    let idx = textLower.indexOf(termLower);
    while (idx !== -1) {
        const before = idx === 0 || !isWordChar(textLower[idx - 1]);
        const after = idx + termLower.length >= textLower.length ||
            !isWordChar(textLower[idx + termLower.length]);
        if (before && after)
            return true;
        idx = textLower.indexOf(termLower, idx + 1);
    }
    return false;
}
/**
 * Generates unigrams, bigrams, and trigrams from cleaned text.
 * Enables multi-word synonym keys like "jerome powell" or "rate cut".
 */
function extractPhrases(text) {
    const words = text.toLowerCase().split(/\s+/).filter(w => w.length > 0);
    const phrases = [...words];
    for (let i = 0; i < words.length - 1; i++) {
        phrases.push(words[i] + ' ' + words[i + 1]);
    }
    for (let i = 0; i < words.length - 2; i++) {
        phrases.push(words[i] + ' ' + words[i + 1] + ' ' + words[i + 2]);
    }
    return phrases;
}
/**
 * Expands a token list with synonyms from SYNONYM_MAP.
 * Both the original tokens and their aliases are included.
 */
function expandWithSynonyms(tokens) {
    const expanded = new Set(tokens);
    for (const token of tokens) {
        const syns = SYNONYM_MAP[token.toLowerCase()];
        if (syns) {
            for (const s of syns)
                expanded.add(s);
        }
    }
    return Array.from(expanded);
}
/**
 * Extracts meaningful tokens from a market title for supplementary matching.
 * These are weighted lower than explicit market keywords.
 */
function extractTitleTokens(title) {
    const TITLE_STOPS = new Set([
        'will', 'the', 'a', 'an', 'in', 'on', 'at', 'by', 'for', 'to', 'of',
        'and', 'or', 'is', 'be', 'has', 'have', 'are', 'was', 'were', 'been',
        'do', 'does', 'did', '2024', '2025', '2026', '2027', 'before', 'after',
        'end', 'yes', 'no', 'than', 'over', 'under', 'above', 'below', 'hit',
        'reach', 'win', 'lose', 'pass', 'major', 'us', 'use', 'its', 'their',
        'any', 'all', 'into', 'out', 'up', 'down',
        'world', 'cup', 'game', 'games', 'live', 'work', 'way', 'show', 'back',
        'know', 'good', 'big', 'take', 'top', 'open', 'run', 'real', 'right',
        'mean', 'only', 'even', 'well', 'off', 'look', 'find', 'going', 'come',
        'make', 'made', 'day', 'days', 'part', 'true', 'keep', 'left', 'try',
        'give', 'once', 'ever', 'much', 'many', 'other', 'every', 'again',
        'move', 'play', 'long', 'high', 'side', 'line', 'lead', 'role', 'hold',
        'plan', 'place', 'start', 'see', 'say', 'said', 'goes',
        'man', 'men', 'city', 'united', 'new', 'old', 'final', 'league',
    ]);
    return title
        .toLowerCase()
        .replace(/[^a-z0-9\s']/g, ' ')
        .split(/\s+/)
        .filter(w => w.length > 2 && !TITLE_STOPS.has(w));
}
// ─── Scoring ─────────────────────────────────────────────────────────────────
// Cap the normalization denominator so markets with large keyword lists
// (20-40 keywords from description extraction) don't get artificially low scores.
// Without this cap, a perfect bitcoin+btc+crypto match on a 25-keyword market
// scores 2.2/25 = 0.088 — below threshold despite being a strong signal.
// ─── Promotional/Spam Content Detection ──────────────────────────────────────
const PROMOTIONAL_PATTERNS = (/* unused pure expression or super */ null && ([
    // Financial scams / trading promotions
    /\$\d+k.*pass.*test/i, // "$100K if you pass test"
    /won't give you.*we will/i, // "Your bank won't give you, we will"
    /no deposits.*profits/i, // "No deposits, keep profits"
    /worst case.*lose.*fee/i, // "Worst case you lose the entry fee"
    /free \$\d+/i, // "Free $500"
    /claim.*\$\d+/i, // "Claim your $100"
    /limited.*offer/i, // "Limited time offer"
    /click.*link.*bio/i, // "Click link in bio"
    /dm.*for.*more/i, // "DM me for more info"
    /join.*discord/i, // Promotional Discord links
    /airdrop/i, // Crypto airdrops
    /whitelist/i, // NFT/crypto whitelists
    /presale/i, // Token presales
    /guaranteed.*profit/i, // "Guaranteed profits"
    /risk[- ]free/i, // "Risk-free trading"
]));
/**
 * Detect if a tweet is promotional/spam content
 * Returns true if tweet matches promotional patterns
 */
function isPromotionalContent(text) {
    const normalized = text.toLowerCase();
    // Check against known promotional patterns
    for (const pattern of PROMOTIONAL_PATTERNS) {
        if (pattern.test(text)) {
            return true;
        }
    }
    // Excessive emoji usage (often in spam)
    const emojiCount = (text.match(/[\uD800-\uDFFF]/g) || []).length;
    if (emojiCount > 15 && text.length < 200) {
        return true; // More than 15 emoji chars in a short tweet is suspicious
    }
    // Multiple dollar amounts with no context (often scams)
    const dollarMatches = text.match(/\$\d+[KMB]?/gi);
    if (dollarMatches && dollarMatches.length >= 3) {
        // 3+ different dollar amounts mentioned = likely promotional
        return true;
    }
    return false;
}
// ─── Category coherence detection ───────────────────────────────────────────
// Category-related term clusters for coherence detection
const CATEGORY_CLUSTERS = {
    gaming: new Set(['gaming', 'video game', 'console', 'esports', 'pc', 'steam', 'playstation', 'xbox', 'nintendo', 'switch', 'gta', 'minecraft', 'valorant']),
    crypto: new Set(['crypto', 'cryptocurrency', 'bitcoin', 'ethereum', 'btc', 'eth', 'blockchain', 'defi', 'web3', 'solana', 'nft']),
    music: new Set(['music', 'album', 'tour', 'concert', 'artist', 'song', 'single', 'spotify', 'streaming music', 'coachella', 'festival']),
    tech: new Set(['tech', 'technology', 'ai', 'software', 'startup', 'silicon valley', 'coding', 'developer', 'nvidia', 'openai']),
    sports: new Set(['sports', 'team', 'championship', 'playoff', 'season', 'athlete', 'coach', 'league', 'nfl', 'nba']),
    politics: new Set(['politics', 'election', 'congress', 'president', 'senate', 'house', 'vote', 'bill', 'policy']),
    finance: new Set(['stock', 'stocks', 'market', 'trading', 'wall street', 'ipo', 'shares', 'investor']),
};
/**
 * Detects category coherence - gives bonus when tweet contains multiple related terms
 * from the same category, indicating strong topical focus
 */
function getCategoryCoherenceBonus(matchedKeywords, marketCategory) {
    for (const [category, terms] of Object.entries(CATEGORY_CLUSTERS)) {
        const matchedInCategory = matchedKeywords.filter(kw => terms.has(kw.toLowerCase())).length;
        // If we have 3+ terms from same category, strong signal
        if (matchedInCategory >= 3) {
            // Extra boost if market category aligns
            return marketCategory === category ? 0.15 : 0.1;
        }
        // 2 terms from same category is moderate signal
        if (matchedInCategory === 2) {
            return marketCategory === category ? 0.08 : 0.05;
        }
    }
    return 0;
}
/**
 * Recency boost - markets ending soon are more relevant
 */
function getRecencyBoost(market) {
    if (!market.endDate)
        return 0;
    try {
        const endDate = new Date(market.endDate);
        const now = new Date();
        const daysUntilEnd = (endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
        // Markets ending within 30 days get a small boost
        if (daysUntilEnd > 0 && daysUntilEnd <= 30) {
            return 0.05;
        }
        // Markets ending within 7 days get bigger boost
        if (daysUntilEnd > 0 && daysUntilEnd <= 7) {
            return 0.1;
        }
    }
    catch (e) {
        // Invalid date, no boost
    }
    return 0;
}
/**
 * Numeric context detection
 * Helps match price targets, dates, percentages mentioned in tweets
 */
function extractNumericContexts(text) {
    const contexts = new Set();
    // Price targets: $100, $50K, $1M, etc.
    const priceMatches = text.matchAll(/\$(\d+(?:,\d{3})*(?:\.\d+)?[KMB]?)/gi);
    for (const match of priceMatches) {
        contexts.add(`price:${match[1].toLowerCase()}`);
    }
    // Percentages: 5%, 10%, etc.
    const percentMatches = text.matchAll(/(\d+(?:\.\d+)?)%/g);
    for (const match of percentMatches) {
        contexts.add(`percent:${match[1]}`);
    }
    // Years: 2024-2029, etc.
    const yearMatches = text.matchAll(/\b(202[4-9])\b/g);
    for (const match of yearMatches) {
        contexts.add(`year:${match[1]}`);
    }
    return contexts;
}
const DENOMINATOR_CAP = 5;
function computeScore(r, market, matchedKeywords) {
    if (r.totalChecked === 0)
        return 0;
    // Weighted sum: exact > synonym > title
    const weighted = r.exactMatches * 1.0 +
        r.synonymMatches * 0.5 + // Reduced from 0.6 to reduce weak synonym matches
        r.titleMatches * 0.15; // Reduced from 0.3 to reduce title noise
    // Normalize by keyword list length, capped to avoid penalizing markets
    // that happen to have many keywords from description extraction.
    const denominator = Math.min(r.totalChecked, DENOMINATOR_CAP);
    const normalized = weighted / denominator;
    const totalMatched = r.exactMatches + r.synonymMatches + r.titleMatches;
    // STRICT FILTERING: Require at least 2 matches for confidence
    // Exception: single exact match with normalized ≥ 0.4 (very specific markets)
    if (totalMatched === 1) {
        // Only allow single matches if:
        // 1. It's an exact match (not synonym/title)
        // 2. Normalized score is very high (≥ 0.4, meaning market has ≤2 focused keywords)
        if (r.exactMatches === 0 || normalized < 0.4) {
            return 0;
        }
    }
    // If only title matches (no exact or synonym), require at least 3 title words
    if (r.exactMatches === 0 && r.synonymMatches === 0 && r.titleMatches < 3) {
        return 0;
    }
    // Small coverage bonus for matching multiple distinct keywords
    const coverageBonus = Math.min(0.2, (totalMatched - 1) * 0.05);
    // Phrase bonus: multi-word matches are much more specific than single words
    // Each phrase match adds 0.1 confidence (capped at 0.3)
    const phraseBonus = Math.min(0.3, r.multiWordMatches * 0.1);
    // Category coherence bonus
    const coherenceBonus = getCategoryCoherenceBonus(matchedKeywords, market.category || '');
    // Recency boost
    const recencyBoost = getRecencyBoost(market);
    return Math.min(1.0, normalized + (totalMatched > 0 ? coverageBonus : 0) + phraseBonus + coherenceBonus + recencyBoost);
}
// ─── KeywordMatcher class ────────────────────────────────────────────────────
class KeywordMatcher {
    constructor(markets = mockMarkets, minConfidence = 0.22, // Raised from 0.12 to reduce false positives
    maxResults = 5) {
        this.markets = markets;
        this.minConfidence = minConfidence;
        this.maxResults = maxResults;
    }
    /**
     * Match a tweet to relevant markets, returning results sorted by confidence.
     */
    match(tweetText) {
        // Filter out very short tweets (likely noise or greetings)
        if (tweetText.trim().length < 20)
            return [];
        // Step 1: Extract raw tokens (unigrams + bigrams + trigrams) from tweet
        const rawTokens = this.extractKeywords(tweetText);
        if (rawTokens.length === 0)
            return [];
        // Step 2: Expand with synonyms — done once, reused for all markets
        const expandedTokens = expandWithSynonyms(rawTokens);
        const rawTokenSet = new Set(rawTokens);
        const expandedTokenSet = new Set(expandedTokens);
        const matches = [];
        for (const market of this.markets) {
            const result = this.scoreMarket(market, rawTokenSet, expandedTokenSet);
            if (result.confidence >= this.minConfidence) {
                matches.push(result);
            }
        }
        matches.sort((a, b) => b.confidence - a.confidence);
        return matches.slice(0, this.maxResults);
    }
    /**
     * Extract and clean keywords from tweet text.
     * Returns unigrams + bigrams + trigrams, filtered for noise.
     */
    extractKeywords(text) {
        let normalized = text.toLowerCase();
        // Remove URLs and mentions
        normalized = normalized.replace(/https?:\/\/[^\s]+/g, '');
        normalized = normalized.replace(/@\w+/g, '');
        // Extract hashtags as plain words
        const hashtags = Array.from(text.matchAll(/#(\w+)/g)).map(m => m[1].toLowerCase());
        // Remove special chars, preserve & for "s&p"
        normalized = normalized.replace(/[^a-z0-9\s&']/g, ' ');
        normalized = normalized.replace(/\s+/g, ' ').trim();
        // Generate unigrams + bigrams + trigrams
        const phrases = extractPhrases(normalized);
        // Filter: single tokens must pass stop-word + noise-word checks
        const filtered = phrases.filter(token => {
            if (token.includes(' ')) {
                // Multi-word phrases: only length filter (phrases are inherently specific)
                return token.length > 4;
            }
            return (token.length > 2 &&
                !STOP_WORDS.has(token) &&
                !DOMAIN_NOISE_WORDS.has(token));
        });
        // Merge with hashtags and deduplicate
        return [...new Set([...filtered, ...hashtags])];
    }
    /**
     * Score a single market against the pre-computed tweet token sets.
     */
    scoreMarket(market, rawTokenSet, expandedTokenSet) {
        const matchedKeywords = [];
        let exactMatches = 0;
        let synonymMatches = 0;
        let titleMatches = 0;
        let multiWordMatches = 0; // Track phrase matches for prioritization
        const explicitKeywords = market.keywords.map(k => k.toLowerCase());
        // PRIORITY 1: Multi-word phrases (most specific)
        for (const mk of explicitKeywords) {
            if (mk.includes(' ')) {
                if (hasWordBoundaryMatch(Array.from(rawTokenSet).join(' '), mk)) {
                    exactMatches++;
                    multiWordMatches++;
                    matchedKeywords.push(mk);
                }
                else if (hasWordBoundaryMatch(Array.from(expandedTokenSet).join(' '), mk)) {
                    synonymMatches++;
                    multiWordMatches++;
                    matchedKeywords.push(mk);
                }
            }
        }
        // PRIORITY 2: Single-word exact/synonym matches
        for (const mk of explicitKeywords) {
            if (!mk.includes(' ') && !matchedKeywords.includes(mk)) {
                if (expandedTokenSet.has(mk)) {
                    if (rawTokenSet.has(mk)) {
                        exactMatches++;
                    }
                    else {
                        synonymMatches++;
                    }
                    matchedKeywords.push(mk);
                }
            }
        }
        // Title-word fallback: check if any tweet token appears in the market title.
        // Weighted lower than explicit keyword matches; catches cases where
        // generateKeywords() misses a term that's clearly in the title.
        const titleTokens = extractTitleTokens(market.title);
        for (const tt of titleTokens) {
            if (!matchedKeywords.includes(tt) && expandedTokenSet.has(tt)) {
                titleMatches++;
                matchedKeywords.push(tt);
            }
        }
        const confidence = computeScore({
            exactMatches,
            synonymMatches,
            titleMatches,
            totalChecked: explicitKeywords.length,
            multiWordMatches,
        }, market, matchedKeywords);
        return { market, confidence, matchedKeywords };
    }
    /** Update confidence threshold */
    setMinConfidence(minConfidence) {
        this.minConfidence = minConfidence;
    }
    /** Update max results */
    setMaxResults(maxResults) {
        this.maxResults = maxResults;
    }
}
// Singleton instance
const matcher = new KeywordMatcher();

;// ./src/api/keyword-generator.ts
// Generates market keywords from title + description.
// Uses unigrams only (no bigram noise) plus SYNONYM_MAP forward expansion.
// Including the description means company names, tickers, and context words
// appear as keywords without needing hand-coded SYNONYM_MAP entries.

const TITLE_STOPS = new Set([
    'will', 'the', 'a', 'an', 'in', 'on', 'at', 'by', 'for', 'to', 'of',
    'and', 'or', 'is', 'be', 'has', 'have', 'are', 'was', 'were', 'been',
    'do', 'does', 'did', '2024', '2025', '2026', '2027', '2028', 'before',
    'after', 'end', 'yes', 'no', 'than', 'over', 'under', 'above', 'below',
    'hit', 'reach', 'win', 'lose', 'pass', 'major', 'us', 'use', 'its',
    'their', 'any', 'all', 'into', 'out', 'up', 'down', 'as', 'from',
    'with', 'this', 'that', 'not', 'new', 'more', 'than', 'most', 'least',
    'how', 'what', 'when', 'where', 'who', 'get', 'got', 'put', 'set',
    'per', 'via', 'vs', 'vs.', 'than', 'if', 'whether', 'close', 'below',
    'least', 'value', 'level', 'least', 'each', 'such', 'also', 'still',
    'next', 'last', 'first', 'time', 'market', 'price', 'would',
    // Generic English words that appear in everyday speech but carry no
    // market-specific signal when seen in isolation (e.g. "world" in a
    // FIFA World Cup title would create a spurious keyword that matches
    // tweets mentioning "the world" in an unrelated context).
    // "man city" / "man united" are handled via SYNONYM_MAP bigrams instead.
    'world', 'cup', 'game', 'games', 'live', 'work', 'way', 'show', 'back',
    'know', 'good', 'big', 'take', 'top', 'open', 'run', 'real', 'right',
    'mean', 'only', 'even', 'well', 'off', 'look', 'find', 'going', 'come',
    'make', 'made', 'day', 'days', 'part', 'true', 'keep', 'left', 'try',
    'give', 'once', 'ever', 'much', 'many', 'other', 'every', 'again',
    'move', 'play', 'long', 'high', 'side', 'line', 'lead', 'role', 'hold',
    'plan', 'place', 'start', 'see', 'say', 'said', 'goes',
    'man', 'men', 'city', 'united', 'new', 'old', 'final', 'league',
]);
/** Extract unigrams from a text string, applying stop-word filtering */
function extractUnigrams(text) {
    return text
        .toLowerCase()
        .replace(/[^a-z0-9\s'&$]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .split(' ')
        .filter(w => w.length > 2 && !TITLE_STOPS.has(w));
}
/** Extract bigrams + trigrams that are keys in SYNONYM_MAP */
function extractSynonymPhrases(text) {
    const words = text
        .toLowerCase()
        .replace(/[^a-z0-9\s'&]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .split(' ')
        .filter(w => w.length > 0);
    const phrases = [];
    for (let i = 0; i < words.length - 1; i++) {
        const bigram = words[i] + ' ' + words[i + 1];
        if (SYNONYM_MAP[bigram])
            phrases.push(bigram);
        if (i < words.length - 2) {
            const trigram = words[i] + ' ' + words[i + 1] + ' ' + words[i + 2];
            if (SYNONYM_MAP[trigram])
                phrases.push(trigram);
        }
    }
    return phrases;
}
// Max keywords per market. Keeps the keyword list focused and prevents the
// scoring denominator from being inflated by verbose description text.
const MAX_KEYWORDS = 20;
/**
 * Generates market keywords from title and optional description.
 *
 * Strategy:
 * 1. Extract unigrams from title (stop-word filtered) — no bigram noise
 * 2. Extract bigrams/trigrams from title ONLY if they are SYNONYM_MAP keys
 * 3. Apply SYNONYM_MAP forward expansion for all tokens found
 * 4. Extract unigrams from first 300 chars of description for extra context
 *    (company names, tickers, etc. not present in the title)
 * 5. Cap total at MAX_KEYWORDS, prioritising title-derived keywords
 * 6. Deduplicate and return
 */
function generateKeywords(title, description) {
    const titleKeywords = new Set();
    const descKeywords = new Set();
    // ── Title: unigrams ──────────────────────────────────────────────────────
    const titleUnigrams = extractUnigrams(title);
    for (const token of titleUnigrams) {
        titleKeywords.add(token);
        const syns = SYNONYM_MAP[token];
        if (syns)
            syns.forEach(s => titleKeywords.add(s));
    }
    // ── Title: known multi-word aliases (bigrams/trigrams in SYNONYM_MAP) ───
    for (const phrase of extractSynonymPhrases(title)) {
        titleKeywords.add(phrase);
        const syns = SYNONYM_MAP[phrase];
        if (syns)
            syns.forEach(s => titleKeywords.add(s));
    }
    // ── Description: unigrams from first 300 chars (supplementary only) ─────
    if (description) {
        const descUnigrams = extractUnigrams(description.slice(0, 300));
        for (const token of descUnigrams) {
            if (!titleKeywords.has(token)) {
                descKeywords.add(token);
                const syns = SYNONYM_MAP[token];
                if (syns)
                    syns.forEach(s => descKeywords.add(s));
            }
        }
    }
    // Title keywords always included first; description fills up to the cap.
    const result = Array.from(titleKeywords);
    for (const k of descKeywords) {
        if (result.length >= MAX_KEYWORDS)
            break;
        result.push(k);
    }
    return result;
}

;// ./src/api/polymarket-client.ts
// Polymarket public API client
// Fetches live binary prediction markets and maps them to the internal Market interface.
// No authentication required — public read-only endpoint with no CORS restrictions.

const POLYMARKET_API = 'https://gamma-api.polymarket.com';
/**
 * Returns true only for simple binary Yes/No markets.
 * Filters out multi-outcome and non-binary markets.
 */
function isBinaryMarket(pm) {
    if (!pm.question || !pm.conditionId || !pm.slug)
        return false;
    if (!pm.active || pm.closed)
        return false;
    try {
        const outcomes = JSON.parse(pm.outcomes);
        if (outcomes.length !== 2)
            return false;
        // Must be a Yes/No market
        const lower = outcomes.map(o => o.toLowerCase());
        if (!lower.includes('yes') || !lower.includes('no'))
            return false;
    }
    catch {
        return false;
    }
    return true;
}
/**
 * Fetch active binary markets from Polymarket's public gamma API.
 * Uses cursor-based pagination until we have enough markets.
 */
async function fetchPolymarkets(targetCount = 500, maxPages = 10) {
    const PAGE_SIZE = 100;
    const allMarkets = [];
    let offset = 0;
    for (let page = 0; page < maxPages; page++) {
        const url = `${POLYMARKET_API}/markets?closed=false&active=true` +
            `&order=volume24hrClob&ascending=false` +
            `&limit=${PAGE_SIZE}&offset=${offset}`;
        const resp = await fetch(url);
        if (!resp.ok) {
            console.error(`[Musashi SW] Polymarket HTTP ${resp.status}`);
            throw new Error(`Polymarket API responded with ${resp.status}`);
        }
        const data = await resp.json();
        if (!Array.isArray(data)) {
            throw new Error('Unexpected Polymarket API response shape');
        }
        if (data.length === 0)
            break; // no more results
        const pageBinary = data
            .filter(isBinaryMarket)
            .map(toMarket)
            .filter(m => m.yesPrice > 0 && m.yesPrice < 1);
        allMarkets.push(...pageBinary);
        console.log(`[Musashi] Polymarket page ${page + 1}: ${data.length} raw → ` +
            `${pageBinary.length} binary (total: ${allMarkets.length})`);
        if (allMarkets.length >= targetCount || data.length < PAGE_SIZE)
            break;
        offset += PAGE_SIZE;
    }
    console.log(`[Musashi] Fetched ${allMarkets.length} live markets from Polymarket`);
    return allMarkets.slice(0, targetCount);
}
/** Map a raw Polymarket market object to our Market interface */
function toMarket(pm) {
    let yesPrice = 0.5;
    try {
        const prices = JSON.parse(pm.outcomePrices);
        const outcomes = JSON.parse(pm.outcomes);
        // Find the index of "Yes" in outcomes
        const yesIdx = outcomes.findIndex(o => o.toLowerCase() === 'yes');
        if (yesIdx !== -1 && prices[yesIdx] != null) {
            yesPrice = parseFloat(prices[yesIdx]);
        }
    }
    catch {
        // fallback to 0.5
    }
    const safeYes = Math.min(Math.max(yesPrice, 0.01), 0.99);
    const safeNo = +((1 - safeYes).toFixed(2));
    return {
        id: `polymarket-${pm.conditionId}`,
        platform: 'polymarket',
        title: pm.question,
        description: pm.description ?? '',
        keywords: generateKeywords(pm.question, pm.description),
        yesPrice: +safeYes.toFixed(2),
        noPrice: safeNo,
        volume24h: pm.volume24hr ?? 0,
        url: `https://polymarket.com/event/${pm.events?.[0]?.slug ?? pm.slug}`,
        category: inferCategory(pm.question, pm.category),
        lastUpdated: new Date().toISOString(),
        numericId: pm.id,
        oneDayPriceChange: pm.oneDayPriceChange ?? 0,
        endDate: pm.endDateIso ?? undefined,
    };
}
/** Infer a rough category from the market question text */
function inferCategory(question, apiCategory) {
    if (apiCategory) {
        const c = apiCategory.toLowerCase();
        if (c.includes('crypto') || c.includes('bitcoin'))
            return 'crypto';
        if (c.includes('politic') || c.includes('elect'))
            return 'us_politics';
        if (c.includes('sport') || c.includes('nfl') || c.includes('nba'))
            return 'sports';
        if (c.includes('tech'))
            return 'technology';
    }
    const q = question.toUpperCase();
    if (/BTC|ETH|CRYPTO|SOL|XRP|DOGE|BITCOIN|ETHEREUM/.test(q))
        return 'crypto';
    if (/FED|CPI|GDP|INFLATION|RATE|RECESSION|UNEMP|JOBS/.test(q))
        return 'economics';
    if (/TRUMP|BIDEN|HARRIS|PRES|CONGRESS|SENATE|ELECT|GOP|DEM|HOUSE/.test(q))
        return 'us_politics';
    if (/NVDA|AAPL|MSFT|GOOGLE|META|AMAZON|AI|OPENAI|TECH|TESLA/.test(q))
        return 'technology';
    if (/NFL|NBA|MLB|NHL|SUPER BOWL|WORLD CUP|FIFA|GOLF|TENNIS/.test(q))
        return 'sports';
    if (/CLIMATE|WEATHER|CARBON|ENERGY|OIL/.test(q))
        return 'climate';
    if (/UKRAINE|RUSSIA|CHINA|NATO|TAIWAN|ISRAEL|GAZA|IRAN/.test(q))
        return 'geopolitics';
    return 'other';
}

;// ./src/api/kalshi-client.ts
// Kalshi public API client
// Fetches live open markets and maps them to the internal Market interface.
// No authentication required — these are public read-only endpoints.

const KALSHI_API = 'https://api.elections.kalshi.com/trade-api/v2';
/**
 * Returns true for simple binary YES/NO markets.
 * Filters out complex multi-variable event (parlay/combo) markets whose
 * titles are multi-leg strings like "yes Lakers, yes Celtics, no Bulls..."
 */
function isSimpleMarket(km) {
    if (!km.title || !km.ticker)
        return false;
    // MVE / multi-game parlay markets
    if (km.mve_collection_ticker)
        return false;
    if (/MULTIGAME|MVE/i.test(km.ticker))
        return false;
    // Titles that start with "yes " are multi-leg combo selections
    if (/^yes\s/i.test(km.title.trim()))
        return false;
    // More than 2 commas = likely a multi-leg title
    const commas = (km.title.match(/,/g) || []).length;
    if (commas > 2)
        return false;
    return true;
}
/**
 * Fetch open markets from Kalshi's public API using cursor pagination.
 *
 * The default API ordering puts thousands of MVE (parlay/sports) markets first.
 * isSimpleMarket() filters those out, so we must page through until we have
 * enough simple binary markets for meaningful tweet matching.
 *
 * Stops when we reach `targetSimpleCount` simple markets or exhaust `maxPages`.
 */
async function fetchKalshiMarkets(targetSimpleCount = 400, maxPages = 15) {
    const PAGE_SIZE = 200;
    const allSimple = [];
    let cursor;
    for (let page = 0; page < maxPages; page++) {
        const url = cursor
            ? `${KALSHI_API}/markets?status=open&mve_filter=exclude&limit=${PAGE_SIZE}&cursor=${encodeURIComponent(cursor)}`
            : `${KALSHI_API}/markets?status=open&mve_filter=exclude&limit=${PAGE_SIZE}`;
        const resp = await fetch(url);
        if (!resp.ok) {
            console.error(`[Musashi SW] Kalshi HTTP ${resp.status} — declarativeNetRequest header stripping may not be active yet`);
            throw new Error(`Kalshi API responded with ${resp.status}`);
        }
        const data = await resp.json();
        if (!Array.isArray(data.markets)) {
            throw new Error('Unexpected Kalshi API response shape');
        }
        const pageSimple = data.markets
            .filter(isSimpleMarket)
            .map(kalshi_client_toMarket)
            .filter(m => m.yesPrice > 0 && m.yesPrice < 1);
        allSimple.push(...pageSimple);
        console.log(`[Musashi] Page ${page + 1}: ${data.markets.length} raw → ` +
            `${pageSimple.length} simple (total simple: ${allSimple.length})`);
        // Stop early once we have enough, or when the API has no more pages
        if (allSimple.length >= targetSimpleCount || !data.cursor)
            break;
        cursor = data.cursor;
    }
    console.log(`[Musashi] Fetched ${allSimple.length} live markets from Kalshi`);
    return allSimple;
}
/** Map a raw Kalshi market object to our Market interface */
function kalshi_client_toMarket(km) {
    // Prefer the _dollars variant (already 0–1); fall back to /100 conversion
    let yesPrice;
    if (km.yes_bid_dollars != null && km.yes_ask_dollars != null && km.yes_ask_dollars > 0) {
        yesPrice = (km.yes_bid_dollars + km.yes_ask_dollars) / 2;
    }
    else if (km.yes_bid != null && km.yes_ask != null && km.yes_ask > 0) {
        yesPrice = ((km.yes_bid + km.yes_ask) / 2) / 100;
    }
    else if (km.last_price_dollars != null && km.last_price_dollars > 0) {
        yesPrice = km.last_price_dollars;
    }
    else if (km.last_price != null && km.last_price > 0) {
        yesPrice = km.last_price / 100;
    }
    else {
        yesPrice = 0.5;
    }
    const safeYes = Math.min(Math.max(yesPrice, 0.01), 0.99);
    const safeNo = +((1 - safeYes).toFixed(2));
    // ── URL construction ───────────────────────────────────────────────────────
    // Kalshi web URLs follow: kalshi.com/markets/{series}/{slug}/{event_ticker}
    // The API does NOT return series_ticker, so we always derive it via extractSeriesTicker().
    // The middle slug segment is SEO-only; Kalshi redirects any slug to the canonical one.
    // The final segment MUST be the event_ticker (not market ticker), lowercase.
    const seriesTicker = (km.series_ticker || extractSeriesTicker(km.event_ticker ?? km.ticker))
        .toLowerCase();
    const eventTickerLower = (km.event_ticker ?? km.ticker).toLowerCase();
    const titleSlug = slugify(km.title);
    const marketUrl = `https://kalshi.com/markets/${seriesTicker}/${titleSlug}/${eventTickerLower}`;
    return {
        id: `kalshi-${km.ticker}`,
        platform: 'kalshi',
        title: km.title,
        description: '',
        keywords: generateKeywords(km.title),
        yesPrice: +safeYes.toFixed(2),
        noPrice: safeNo,
        volume24h: km.volume_24h ?? km.volume ?? 0,
        url: marketUrl,
        category: kalshi_client_inferCategory(km.series_ticker || km.event_ticker || km.ticker),
        lastUpdated: new Date().toISOString(),
    };
}
/** Convert a market title to a URL-safe slug (middle segment of Kalshi URLs) */
function slugify(text) {
    return text
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '')
        .replace(/\s+/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '');
}
/**
 * Extracts the series ticker from an event_ticker or market ticker.
 * Kalshi event tickers follow: {SERIES}-{DATE_OR_DESCRIPTOR}
 * e.g. "KXBTC-26FEB1708"  → "KXBTC"
 *      "KXGEMINI-VS-CHATGPT" → "KXGEMINI"
 *      "PRES-DEM-2024" → "PRES"
 */
function extractSeriesTicker(ticker) {
    // Try splitting on '-' and returning up to the first segment that
    // looks like a date (digits followed by letters) or is all-caps alpha-only
    const parts = ticker.split('-');
    if (parts.length === 1)
        return parts[0];
    // If second segment starts with digits (looks like a date: 26FEB, 2024, etc.)
    // → series is just the first part
    if (/^\d/.test(parts[1]))
        return parts[0];
    // Otherwise return the first two parts joined
    // e.g. KXGEMINI-VS → "KXGEMINI-VS" would still 404; just use first segment
    return parts[0];
}
/** Infer a rough category from the market's series/event ticker prefix */
function kalshi_client_inferCategory(ticker) {
    const t = ticker.toUpperCase();
    if (/BTC|ETH|CRYPTO|SOL|XRP|DOGE|NFT|DEFI/.test(t))
        return 'crypto';
    if (/FED|CPI|GDP|INFL|RATE|ECON|UNEMP|JOBS|RECESS/.test(t))
        return 'economics';
    if (/TRUMP|BIDEN|PRES|CONG|SENATE|ELECT|GOP|DEM|HOUSE/.test(t))
        return 'us_politics';
    if (/NVDA|AAPL|MSFT|GOOGL|META|AMZN|AI|TECH|TSLA|OPENAI/.test(t))
        return 'technology';
    if (/NFL|NBA|MLB|NHL|SPORT|SUPER|WORLD|FIFA|GOLF|TENNIS/.test(t))
        return 'sports';
    if (/CLIMATE|TEMP|WEATHER|CARBON|EMISS|ENERGY|OIL/.test(t))
        return 'climate';
    if (/UKRAIN|RUSSIA|CHINA|NATO|TAIWAN|ISRAEL|GAZA|IRAN/.test(t))
        return 'geopolitics';
    return 'other';
}

;// ./src/api/deepseek-client.ts
/**
 * DeepSeek API client for advanced sentiment analysis
 */
const DEEPSEEK_API_URL = 'https://api.deepseek.com/v1/chat/completions';
/**
 * Analyze text sentiment using DeepSeek API
 */
async function analyzeWithDeepSeek(request, apiKey) {
    try {
        const prompt = buildAnalysisPrompt(request);
        const response = await fetch(DEEPSEEK_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`,
            },
            body: JSON.stringify({
                model: 'deepseek-chat',
                messages: [
                    {
                        role: 'system',
                        content: 'You are a prediction market analyst. Analyze text for sentiment and provide trading recommendations for prediction markets like Polymarket and Kalshi. Always respond in valid JSON format.',
                    },
                    {
                        role: 'user',
                        content: prompt,
                    },
                ],
                temperature: 0.3, // Lower temperature for more consistent analysis
                max_tokens: 500,
                response_format: { type: 'json_object' },
            }),
        });
        if (!response.ok) {
            throw new Error(`DeepSeek API error: ${response.status} ${response.statusText}`);
        }
        const data = await response.json();
        const content = data.choices[0]?.message?.content;
        if (!content) {
            throw new Error('No response from DeepSeek API');
        }
        const result = JSON.parse(content);
        return result;
    }
    catch (error) {
        console.error('[Musashi] DeepSeek API error:', error);
        // Fallback to neutral sentiment
        return {
            sentiment: 'neutral',
            confidence: 0,
            reasoning: 'Analysis failed',
            marketAction: 'hold',
            actionConfidence: 0,
            keyPoints: [],
            riskLevel: 'high',
        };
    }
}
/**
 * Build analysis prompt for DeepSeek
 */
function buildAnalysisPrompt(request) {
    let prompt = `Analyze the following text for prediction market trading insights:\n\n"${request.text}"\n\n`;
    if (request.marketTitle) {
        prompt += `Related Market: "${request.marketTitle}"\n\n`;
    }
    if (request.context) {
        prompt += `Context: ${request.context}\n\n`;
    }
    prompt += `Provide analysis in this exact JSON format:
{
  "sentiment": "bullish" | "bearish" | "neutral",
  "confidence": 0.0-1.0,
  "reasoning": "brief explanation",
  "marketAction": "buy" | "sell" | "hold",
  "actionConfidence": 0.0-1.0,
  "keyPoints": ["point 1", "point 2", "point 3"],
  "riskLevel": "low" | "medium" | "high"
}

Guidelines:
- sentiment: Overall sentiment toward the event/outcome
- confidence: How confident you are in the sentiment (0-1)
- reasoning: 1-2 sentence explanation
- marketAction: Recommended action for prediction markets
- actionConfidence: Confidence in the trading recommendation (0-1)
- keyPoints: 2-4 key insights from the text
- riskLevel: Risk assessment for taking a position

Focus on factual analysis and clear signals.`;
    return prompt;
}
/**
 * Batch analyze multiple texts
 */
async function batchAnalyzeWithDeepSeek(texts, apiKey) {
    const results = await Promise.all(texts.map((text) => analyzeWithDeepSeek({ text }, apiKey)));
    return results;
}
/**
 * Aggregate sentiment from multiple analyses
 */
function aggregateSentiment(results) {
    if (results.length === 0) {
        return {
            sentiment: 'neutral',
            confidence: 0,
            reasoning: 'No data to analyze',
            marketAction: 'hold',
            actionConfidence: 0,
            keyPoints: [],
            riskLevel: 'high',
        };
    }
    // Count sentiments
    const sentimentCounts = {
        bullish: 0,
        bearish: 0,
        neutral: 0,
    };
    let totalConfidence = 0;
    const allKeyPoints = [];
    let riskScore = 0;
    results.forEach((result) => {
        sentimentCounts[result.sentiment]++;
        totalConfidence += result.confidence;
        allKeyPoints.push(...result.keyPoints);
        // Risk scoring
        if (result.riskLevel === 'high')
            riskScore += 3;
        else if (result.riskLevel === 'medium')
            riskScore += 2;
        else
            riskScore += 1;
    });
    // Determine overall sentiment
    const maxSentiment = Object.entries(sentimentCounts).reduce((a, b) => sentimentCounts[a[0]] >
        sentimentCounts[b[0]]
        ? a
        : b)[0];
    const avgConfidence = totalConfidence / results.length;
    const avgRiskScore = riskScore / results.length;
    const riskLevel = avgRiskScore < 1.5 ? 'low' : avgRiskScore < 2.5 ? 'medium' : 'high';
    // Determine market action
    let marketAction = 'hold';
    if (maxSentiment === 'bullish' && avgConfidence > 0.6)
        marketAction = 'buy';
    else if (maxSentiment === 'bearish' && avgConfidence > 0.6)
        marketAction = 'sell';
    // Get unique key points
    const uniqueKeyPoints = Array.from(new Set(allKeyPoints)).slice(0, 5);
    return {
        sentiment: maxSentiment,
        confidence: avgConfidence,
        reasoning: `Aggregated from ${results.length} analyses`,
        marketAction,
        actionConfidence: avgConfidence,
        keyPoints: uniqueKeyPoints,
        riskLevel,
    };
}

;// ./src/api/external-api.ts
/**
 * External API for AI Agents
 *
 * This module enables AI agents and external applications to access Musashi analysis data
 * via Chrome Extension messaging API.
 *
 * USAGE FOR AI AGENTS:
 *
 * 1. Install Musashi Chrome Extension
 * 2. Get the extension ID from chrome://extensions
 * 3. Use chrome.runtime.sendMessage() to query data
 *
 * Example (from a web page with Musashi extension installed):
 *
 * ```javascript
 * const MUSASHI_EXTENSION_ID = 'your-extension-id-here';
 *
 * // Get all news analyses
 * chrome.runtime.sendMessage(
 *   MUSASHI_EXTENSION_ID,
 *   { type: 'API_GET_NEWS_ANALYSES' },
 *   (response) => {
 *     console.log('News analyses:', response.data);
 *   }
 * );
 * ```
 */
/**
 * API endpoint handlers
 */
function setupExternalApi() {
    // Listen for external messages (from AI agents, scripts, etc.)
    chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
        console.log('[Musashi API] External request:', message.type);
        // Get all news analyses
        if (message.type === 'API_GET_NEWS_ANALYSES') {
            chrome.storage.local.get(['news_analyses']).then((stored) => {
                const analyses = stored.news_analyses || {};
                const data = Object.values(analyses).map(transformAnalysis);
                sendResponse({
                    success: true,
                    data,
                    timestamp: Date.now(),
                });
            });
            return true;
        }
        // Get specific news analysis by ID
        if (message.type === 'API_GET_NEWS_ANALYSIS') {
            const newsId = message.newsId;
            if (!newsId) {
                sendResponse({
                    success: false,
                    error: 'Missing newsId parameter',
                    timestamp: Date.now(),
                });
                return;
            }
            chrome.storage.local.get(['news_analyses']).then((stored) => {
                const analyses = stored.news_analyses || {};
                const analysis = analyses[newsId];
                if (!analysis) {
                    sendResponse({
                        success: false,
                        error: `News analysis not found: ${newsId}`,
                        timestamp: Date.now(),
                    });
                    return;
                }
                sendResponse({
                    success: true,
                    data: transformAnalysis(analysis),
                    timestamp: Date.now(),
                });
            });
            return true;
        }
        // Get all available markets
        if (message.type === 'API_GET_MARKETS') {
            chrome.storage.local.get(['markets_v2']).then((stored) => {
                const markets = stored.markets_v2 || [];
                sendResponse({
                    success: true,
                    data: markets,
                    timestamp: Date.now(),
                });
            });
            return true;
        }
        // Get market signals (filtered by sentiment/action)
        if (message.type === 'API_GET_MARKET_SIGNALS') {
            const filter = message.filter || {}; // { signal: 'buy', minConfidence: 0.7 }
            chrome.storage.local.get(['news_analyses']).then((stored) => {
                const analyses = stored.news_analyses || {};
                let allSignals = [];
                Object.values(analyses).forEach((analysis) => {
                    allSignals.push(...analysis.relatedMarkets);
                });
                // Apply filters
                if (filter.signal) {
                    allSignals = allSignals.filter((s) => s.signal === filter.signal);
                }
                if (filter.minConfidence) {
                    allSignals = allSignals.filter((s) => s.confidence >= filter.minConfidence);
                }
                // Sort by confidence
                allSignals.sort((a, b) => b.confidence - a.confidence);
                sendResponse({
                    success: true,
                    data: allSignals,
                    timestamp: Date.now(),
                });
            });
            return true;
        }
        // Health check
        if (message.type === 'API_HEALTH') {
            chrome.storage.local.get(['markets_v2']).then((stored) => {
                const markets = stored.markets_v2 || [];
                sendResponse({
                    success: true,
                    data: {
                        status: 'healthy',
                        version: '1.0.0',
                        marketsLoaded: markets.length,
                        lastUpdate: Date.now(),
                    },
                    timestamp: Date.now(),
                });
            });
            return true;
        }
        // Get API capabilities and documentation
        if (message.type === 'API_GET_CAPABILITIES') {
            sendResponse({
                success: true,
                data: {
                    name: 'Musashi AI',
                    version: '1.0.0',
                    description: 'AI-powered sentiment analysis and prediction market signals for automated trading',
                    documentation: {
                        main: 'https://musashi.bot/ai',
                        quickstart: 'https://musashi.bot/ai/quickstart',
                        apiReference: 'https://musashi.bot/ai/api-reference',
                        examples: {
                            python: 'https://musashi.bot/ai/examples/python',
                            nodejs: 'https://musashi.bot/ai/examples/nodejs',
                        },
                        strategies: 'https://musashi.bot/ai/strategies',
                        schema: 'https://musashi.bot/ai/schema.json',
                        openapi: 'https://musashi.bot/ai/openapi.yaml',
                    },
                    endpoints: [
                        {
                            type: 'API_GET_NEWS_ANALYSES',
                            description: 'Get AI sentiment analysis for trending news',
                            parameters: {},
                            returns: 'NewsAnalysis[]',
                            example: { type: 'API_GET_NEWS_ANALYSES', data: {} },
                        },
                        {
                            type: 'API_GET_MARKET_SIGNALS',
                            description: 'Get sentiment signals for prediction markets',
                            parameters: { marketId: 'string (optional)' },
                            returns: 'MarketSignal[]',
                            example: { type: 'API_GET_MARKET_SIGNALS', data: {} },
                        },
                        {
                            type: 'API_GET_MARKETS',
                            description: 'Get complete market database (500+ markets)',
                            parameters: {},
                            returns: 'Market[]',
                            example: { type: 'API_GET_MARKETS', data: {} },
                        },
                        {
                            type: 'API_HEALTH',
                            description: 'Check extension health and status',
                            parameters: {},
                            returns: 'HealthData',
                            example: { type: 'API_HEALTH', data: {} },
                        },
                        {
                            type: 'API_GET_CAPABILITIES',
                            description: 'Get API capabilities and documentation links',
                            parameters: {},
                            returns: 'Capabilities',
                            example: { type: 'API_GET_CAPABILITIES', data: {} },
                        },
                    ],
                    usage: {
                        javascript: `chrome.runtime.sendMessage('EXTENSION_ID', { type: 'API_GET_NEWS_ANALYSES', data: {} }, (response) => { console.log(response.data); });`,
                        note: 'Replace EXTENSION_ID with your installed Musashi extension ID from chrome://extensions',
                    },
                    confidenceThresholds: {
                        description: 'Recommended confidence thresholds for trading',
                        minimum: 0.7,
                        high: 0.8,
                        veryHigh: 0.9,
                    },
                    rateLimits: {
                        newsAnalyses: '60-120 seconds',
                        marketSignals: '30-60 seconds per market',
                        marketsDatabase: '15 minutes',
                        note: 'These are recommended polling frequencies, not hard limits',
                    },
                    features: [
                        'Real-time sentiment analysis via DeepSeek AI',
                        'Trading signals with Buy/Sell/Hold recommendations',
                        'Confidence scores for all signals',
                        'Sentiment trend tracking',
                        'Market discovery and filtering',
                        '500+ markets from Polymarket + Kalshi',
                        'Free API access (no authentication required)',
                    ],
                    dataSources: [
                        'Twitter/X (via browser)',
                        'Polymarket API',
                        'Kalshi API',
                        'DeepSeek AI',
                    ],
                    pricing: {
                        cost: 'FREE',
                        note: 'All AI analysis costs are covered by Musashi',
                    },
                },
                timestamp: Date.now(),
            });
            return true;
        }
        // Unknown endpoint
        sendResponse({
            success: false,
            error: `Unknown API endpoint: ${message.type}`,
            timestamp: Date.now(),
        });
    });
    console.log('[Musashi API] External API initialized');
}
/**
 * Transform internal NewsAnalysis to API format
 */
function transformAnalysis(analysis) {
    return {
        newsId: analysis.newsId,
        title: analysis.title,
        timestamp: analysis.timestamp,
        tweetCount: analysis.tweetCount,
        sentiment: {
            sentiment: analysis.overallSentiment.sentiment,
            confidence: analysis.overallSentiment.confidence,
            marketAction: analysis.overallSentiment.marketAction,
            actionConfidence: analysis.overallSentiment.actionConfidence,
            reasoning: analysis.overallSentiment.reasoning,
            keyPoints: analysis.overallSentiment.keyPoints,
            riskLevel: analysis.overallSentiment.riskLevel,
        },
        relatedMarkets: analysis.relatedMarkets.map((m) => ({
            marketId: m.market.id,
            title: m.market.title,
            platform: m.market.platform,
            signal: m.signal,
            confidence: m.confidence,
            currentPrice: m.currentPrice,
            potentialReturn: m.potentialReturn,
            url: m.market.url,
        })),
        sentimentTrend: analysis.sentimentTrend.map((t) => ({
            timestamp: t.timestamp,
            sentiment: t.sentiment,
            confidence: t.confidence,
        })),
    };
}

;// ./src/background/service-worker.ts
// Musashi Service Worker
// Fetches Polymarket + Kalshi markets (bypasses CORS) and stores them in chrome.storage.
// Content script reads from storage — no large-payload message passing needed.




// v2 key — invalidates the old Polymarket-only cache so combined data is fetched fresh
const STORAGE_KEY_MARKETS = 'markets_v2';
const STORAGE_KEY_TS = 'marketsTs_v2';
const STORAGE_KEY_NEWS_ANALYSES = 'news_analyses';
const CACHE_TTL_MS = 30 * 60 * 1000; // 30 minutes
// Hardcoded DeepSeek API key - free for all Musashi users
const DEEPSEEK_API_KEY = 'sk-16e2f4dcccef43d9ad17e66607bf4b82';
console.log('[Musashi SW] Service worker initialized');
// Initialize external API for AI agents
setupExternalApi();
// ── Proactive fetch on install / browser startup ──────────────────────────────
chrome.runtime.onInstalled.addListener(() => { refreshMarkets(); });
chrome.runtime.onStartup.addListener(() => { refreshMarkets(); });
// ── Message handler ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    // Content script asks for markets (cache miss or first load)
    if (message.type === 'FETCH_MARKETS') {
        chrome.storage.local.get([STORAGE_KEY_MARKETS, STORAGE_KEY_TS]).then(async (cached) => {
            const ts = cached[STORAGE_KEY_TS] ?? 0;
            const markets = cached[STORAGE_KEY_MARKETS];
            // Return cached if fresh
            if (Array.isArray(markets) && markets.length > 0 && Date.now() - ts < CACHE_TTL_MS) {
                console.log(`[Musashi SW] Returning ${markets.length} cached markets`);
                sendResponse({ markets });
                return;
            }
            // Fetch fresh
            console.log('[Musashi SW] Fetching fresh markets from Polymarket + Kalshi...');
            const fresh = await refreshMarkets();
            sendResponse({ markets: fresh });
        }).catch((e) => {
            console.error('[Musashi SW] FETCH_MARKETS error:', e);
            sendResponse({ markets: [] });
        });
        return true; // keep channel open for async
    }
    // Badge update from content script
    if (message.type === 'UPDATE_BADGE') {
        const count = message.count || 0;
        if (sender.tab?.id) {
            chrome.action.setBadgeText({ text: count > 0 ? count.toString() : '', tabId: sender.tab.id });
            chrome.action.setBadgeBackgroundColor({ color: '#A8C5DD', tabId: sender.tab.id });
        }
        sendResponse({ success: true });
        return true;
    }
    // DeepSeek sentiment analysis (single text)
    if (message.type === 'ANALYZE_SENTIMENT') {
        (async () => {
            try {
                const result = await analyzeWithDeepSeek({
                    text: message.text,
                    context: message.context,
                    marketTitle: message.marketTitle,
                }, DEEPSEEK_API_KEY);
                sendResponse({ result });
            }
            catch (error) {
                console.error('[Musashi SW] DeepSeek analysis error:', error);
                sendResponse({ error: String(error) });
            }
        })();
        return true;
    }
    // DeepSeek batch analysis (multiple texts)
    if (message.type === 'BATCH_ANALYZE_SENTIMENT') {
        (async () => {
            try {
                const results = await batchAnalyzeWithDeepSeek(message.texts, DEEPSEEK_API_KEY);
                sendResponse({ results });
            }
            catch (error) {
                console.error('[Musashi SW] DeepSeek batch analysis error:', error);
                sendResponse({ error: String(error) });
            }
        })();
        return true;
    }
    // Store news analysis (from content script)
    if (message.type === 'STORE_NEWS_ANALYSIS') {
        chrome.storage.local.get([STORAGE_KEY_NEWS_ANALYSES]).then(async (stored) => {
            const analyses = stored[STORAGE_KEY_NEWS_ANALYSES] || {};
            analyses[message.analysis.newsId] = message.analysis;
            await chrome.storage.local.set({
                [STORAGE_KEY_NEWS_ANALYSES]: analyses,
            });
            sendResponse({ success: true });
        });
        return true;
    }
    // Get news analyses (for API access)
    if (message.type === 'GET_NEWS_ANALYSES') {
        chrome.storage.local.get([STORAGE_KEY_NEWS_ANALYSES]).then((stored) => {
            const analyses = stored[STORAGE_KEY_NEWS_ANALYSES] || {};
            sendResponse({ analyses: Object.values(analyses) });
        });
        return true;
    }
});
// Clear badge when navigating away from Twitter/X
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete') {
        const url = tab.url || '';
        if (!url.includes('twitter.com') && !url.includes('x.com')) {
            chrome.action.setBadgeText({ text: '', tabId });
        }
    }
});
// ── Market refresh ────────────────────────────────────────────────────────────
async function refreshMarkets() {
    try {
        console.log('[Musashi SW] Starting market fetch...');
        // Fetch both sources in parallel; if one fails the other still contributes
        const [polyResult, kalshiResult] = await Promise.allSettled([
            fetchPolymarkets(1000, 15),
            fetchKalshiMarkets(400, 15),
        ]);
        const polyMarkets = polyResult.status === 'fulfilled' ? polyResult.value : [];
        const kalshiMarkets = kalshiResult.status === 'fulfilled' ? kalshiResult.value : [];
        if (polyResult.status === 'rejected') {
            console.error('[Musashi SW] Polymarket fetch failed:', polyResult.reason);
        }
        if (kalshiResult.status === 'rejected') {
            console.error('[Musashi SW] Kalshi fetch failed:', kalshiResult.reason);
        }
        // Merge; dedup by id just in case
        const seen = new Set();
        const markets = [...polyMarkets, ...kalshiMarkets].filter(m => {
            if (seen.has(m.id))
                return false;
            seen.add(m.id);
            return true;
        });
        console.log(`[Musashi SW] Fetched ${polyMarkets.length} Polymarket + ` +
            `${kalshiMarkets.length} Kalshi = ${markets.length} total markets`);
        if (markets.length === 0) {
            console.error('[Musashi SW] WARNING: No markets fetched! Both APIs may be down or blocked.');
        }
        if (markets.length > 0) {
            await chrome.storage.local.set({
                [STORAGE_KEY_MARKETS]: markets,
                [STORAGE_KEY_TS]: Date.now(),
            });
            console.log(`[Musashi SW] Stored ${markets.length} markets`);
        }
        // Clear any previous ERR badge
        chrome.action.setBadgeText({ text: '' });
        return markets;
    }
    catch (e) {
        console.error('[Musashi SW] refreshMarkets failed:', e);
        // Show red ERR badge on ALL tabs so the user can see without opening any console
        chrome.action.setBadgeText({ text: 'ERR' });
        chrome.action.setBadgeBackgroundColor({ color: '#FF4444' });
        return [];
    }
}

/******/ })()
;